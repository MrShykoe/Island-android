package com.mrsh1zuky.island

import kotlin.math.max
import kotlin.math.min

// Тайминг слов внутри строки.
// Если источник дал настоящие времена слов (enhanced LRC или NetEase yrc), используем их.
// Иначе время строки делится между словами по числу слогов и длине: получается похоже на настоящее, но приблизительно.
object Timing {

    private const val VOWELS = "аеёиоуыэюяaeiouyАЕЁИОУЫЭЮЯAEIOUY"
    private val wordRe = Regex("""\S+""")

    private fun weight(w: String): Double {
        val v = w.count { VOWELS.indexOf(it) >= 0 }
        return max(1, v) + 0.35 * w.length
    }

    fun estimate(line: Media.Line): List<Media.Word> {
        val s = line.s
        val spans = wordRe.findAll(s).toList()
        if (spans.isEmpty()) return emptyList()
        val n = s.count { !it.isWhitespace() }
        val window = max(0.3, line.tNext - line.t)
        // поют не дольше, чем «естественно» для такого количества букв; в паузах строка остаётся выделенной
        val natural = n * 0.16 + 0.8
        val dur = min(window * 0.92, natural)
        val total = spans.sumOf { weight(it.value) }
        val res = ArrayList<Media.Word>(spans.size)
        var acc = 0.0
        for (m in spans) {
            val slot = dur * weight(m.value) / total
            val t0 = line.t + acc
            res.add(Media.Word(t0, t0 + max(0.12, slot * 0.9), m.range.first, m.range.last + 1))
            acc += slot
        }
        return res
    }

    private fun smooth(x: Double): Double {
        val c = x.coerceIn(0.0, 1.0)
        return c * c * (3 - 2 * c)
    }

    // Позиция «залитого» текста в символах (с дробной частью) в момент t
    fun charPos(w: List<Media.Word>, t: Double, len: Int): Float {
        if (w.isEmpty()) return len.toFloat()
        if (t <= w[0].t0) return 0f
        for (i in w.indices) {
            val x = w[i]
            if (t < x.t0) return w[i - 1].c1.toFloat()
            if (t <= x.t1) {
                val f = smooth((t - x.t0) / max(0.01, x.t1 - x.t0)).toFloat()
                return x.c0 + f * (x.c1 - x.c0)
            }
        }
        return len.toFloat()
    }
}

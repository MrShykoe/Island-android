package com.mrsh1zuky.island

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

// Единый источник данных о музыке для острова и полноэкранного плеера:
// текущий трек, обложка, состояние воспроизведения и слова песни.
object Media {

    class Line(val t: Double, val s: String)

    interface Listener {
        fun onMedia()
        fun onLyrics()
    }

    private val listeners = LinkedHashSet<Listener>()
    private val main = Handler(Looper.getMainLooper())
    private val cache = HashMap<String, List<Line>?>()
    private var app: Context? = null
    private var msm: MediaSessionManager? = null
    private var listenerName: ComponentName? = null
    private var started = false
    private var trackKey = ""

    var controller: MediaController? = null
        private set
    var title = ""
        private set
    var artist = ""
        private set
    var cover: Bitmap? = null
        private set
    var durationMs = 0L
        private set
    var playing = false
        private set
    var hasAccess = true
        private set
    var lyrics: List<Line>? = null
        private set

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list ?: emptyList()) }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = read()
        override fun onPlaybackStateChanged(state: PlaybackState?) = read()
        override fun onSessionDestroyed() {
            pick(emptyList())
        }
    }

    fun attach(ctx: Context, l: Listener) {
        app = ctx.applicationContext
        listeners.add(l)
        if (!started) {
            start()
        } else {
            l.onMedia()
            l.onLyrics()
        }
    }

    fun detach(l: Listener) {
        listeners.remove(l)
        if (listeners.isEmpty()) stop()
    }

    private fun start() {
        val c = app ?: return
        started = true
        msm = c.getSystemService(MediaSessionManager::class.java)
        listenerName = ComponentName(c, MediaListener::class.java)
        try {
            msm?.addOnActiveSessionsChangedListener(sessionsListener, listenerName)
            hasAccess = true
            pick(msm?.getActiveSessions(listenerName) ?: emptyList())
        } catch (e: SecurityException) {
            hasAccess = false
            fireMedia()
            fireLyrics()
        }
    }

    private fun stop() {
        started = false
        try {
            msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
        }
        controller?.unregisterCallback(callback)
        controller = null
        trackKey = ""
    }

    private fun fireMedia() = listeners.toList().forEach { it.onMedia() }
    private fun fireLyrics() = listeners.toList().forEach { it.onLyrics() }

    private fun pick(list: List<MediaController>) {
        val best = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list.firstOrNull()
        val cur = controller
        if (best != null && cur != null && best.sessionToken == cur.sessionToken) {
            read()
            return
        }
        cur?.unregisterCallback(callback)
        controller = best
        best?.registerCallback(callback)
        read()
    }

    private fun read() {
        val c = controller
        val m = c?.metadata
        title = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        artist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        cover = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        durationMs = m?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        playing = c?.playbackState?.state == PlaybackState.STATE_PLAYING
        fireMedia()

        val key = "$artist|$title"
        if (key != trackKey) {
            trackKey = key
            lyrics = null
            val ctx = app
            if (title.isNotEmpty() && ctx != null && Prefs.get(ctx, Prefs.LYRICS)) {
                if (cache.containsKey(key)) {
                    lyrics = cache[key]
                } else {
                    fetch(key, title, artist, durationMs / 1000.0, Prefs.get(ctx, Prefs.EXTRA))
                }
            }
            fireLyrics()
        }
    }

    private fun fetch(key: String, t: String, a: String, dur: Double, extra: Boolean) {
        Thread {
            val r = LyricsFetcher.fetch(t, a, dur, extra)
            main.post {
                cache[key] = r
                if (key == trackKey) {
                    lyrics = r
                    fireLyrics()
                }
            }
        }.start()
    }

    fun positionMs(): Long {
        val s = controller?.playbackState ?: return 0L
        if (s.state == PlaybackState.STATE_PLAYING) {
            val dt = SystemClock.elapsedRealtime() - s.lastPositionUpdateTime
            return s.position + (dt * s.playbackSpeed).toLong()
        }
        return s.position
    }
}

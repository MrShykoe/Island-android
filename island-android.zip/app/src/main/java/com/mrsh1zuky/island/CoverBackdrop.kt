package com.mrsh1zuky.island

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import kotlin.math.min

// Размытый фон из обложки. Раньше обложка ужималась до 12×12 пикселей и растягивалась на весь экран, отсюда «пиксели».
// Теперь: нормальная копия ~192 px + настоящее гауссово размытие (RenderEffect, Android 12+),
// на старых версиях программное размытие. Смена обложки идёт плавным перекрёстным затуханием.
class CoverBackdrop(ctx: Context, private val blurDp: Float, dim: Int = 0x66000000) : FrameLayout(ctx) {

    private val density = resources.displayMetrics.density
    private val a = layer()
    private val b = layer()
    private val scrim = View(ctx)
    private var front: ImageView = a
    private var shown: Bitmap? = null

    init {
        scrim.setBackgroundColor(dim)
        addView(a, LayoutParams(-1, -1))
        addView(b, LayoutParams(-1, -1))
        addView(scrim, LayoutParams(-1, -1))
        a.alpha = 0f
        b.alpha = 0f
        scrim.alpha = 0f
    }

    private fun layer(): ImageView = ImageView(context).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        // чуть увеличиваем, чтобы края размытия не выглядывали
        scaleX = 1.3f
        scaleY = 1.3f
        if (Build.VERSION.SDK_INT >= 31) {
            val r = blurDp * density
            setRenderEffect(RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP))
        }
    }

    fun set(c: Bitmap?, enabled: Boolean) {
        if (!enabled || c == null) {
            if (shown != null || scrim.alpha > 0f) {
                a.animate().cancel(); b.animate().cancel(); scrim.animate().cancel()
                a.animate().alpha(0f).setDuration(400).start()
                b.animate().alpha(0f).setDuration(400).start()
                scrim.animate().alpha(0f).setDuration(400).start()
            }
            shown = null
            return
        }
        if (c === shown) return
        val bmp = prepare(c) ?: return
        shown = c
        val next = if (front === a) b else a
        next.setImageBitmap(bmp)
        next.animate().cancel()
        next.alpha = 0f
        next.animate().alpha(1f).setDuration(650).start()
        front.animate().cancel()
        front.animate().alpha(0f).setDuration(650).start()
        front = next
        scrim.animate().cancel()
        scrim.animate().alpha(1f).setDuration(400).start()
    }

    private fun prepare(c: Bitmap): Bitmap? {
        return try {
            val soft = (if (c.config == Bitmap.Config.HARDWARE) c.copy(Bitmap.Config.ARGB_8888, false) else c) ?: return null
            val side = min(soft.width, soft.height)
            val square = Bitmap.createBitmap(soft, (soft.width - side) / 2, (soft.height - side) / 2, side, side)
            val size = if (Build.VERSION.SDK_INT >= 31) 192 else 48
            val small = Bitmap.createScaledBitmap(square, size, size, true)
            if (Build.VERSION.SDK_INT >= 31) small else boxBlur(small, 4, 3)
        } catch (e: Exception) {
            null
        }
    }

    // Простое программное размытие (несколько проходов box blur) для Android 10–11
    private fun boxBlur(src: Bitmap, radius: Int, passes: Int): Bitmap {
        val w = src.width
        val h = src.height
        var px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        var tmp = IntArray(w * h)
        repeat(passes) {
            blurLine(px, tmp, w, h, radius, true)
            blurLine(tmp, px, w, h, radius, false)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    private fun blurLine(inp: IntArray, out: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val len = if (horizontal) w else h
        val lines = if (horizontal) h else w
        for (l in 0 until lines) {
            for (i in 0 until len) {
                var sr = 0; var sg = 0; var sb = 0; var n = 0
                for (k in -r..r) {
                    val j = (i + k).coerceIn(0, len - 1)
                    val p = if (horizontal) inp[l * w + j] else inp[j * w + l]
                    sr += (p shr 16) and 0xFF; sg += (p shr 8) and 0xFF; sb += p and 0xFF; n++
                }
                val v = (0xFF shl 24) or ((sr / n) shl 16) or ((sg / n) shl 8) or (sb / n)
                if (horizontal) out[l * w + i] = v else out[i * w + l] = v
            }
        }
    }
}

package com.mrsh1zuky.island

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.WindowManager

// Запасной вариант: обычный оверлей «поверх экрана». Статус-бар он не перекрывает, поэтому значки рисуются поверх него.
// Если включена служба спец. возможностей (IslandAccessibilityService), остров рисует она, и этот сервис не нужен.
class IslandService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        if (IslandAccessibilityService.connected || !Prefs.get(this, Prefs.ENABLED) || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        IslandHost.show(this, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        IslandHost.hide(this)
        super.onDestroy()
    }

    private fun startAsForeground() {
        val channelId = "island"
        val nm = getSystemService(NotificationManager::class.java)
        nm?.createNotificationChannel(
            NotificationChannel(channelId, "Island", NotificationManager.IMPORTANCE_MIN)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Island работает")
            .setContentText("Нажми, чтобы открыть настройки")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }
}

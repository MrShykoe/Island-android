package com.mrsh1zuky.island

import android.app.Activity
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.Choreographer
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

// Полноэкранный плеер: размытая обложка на фоне, перемотка, кнопки и слова песни, которые заливаются вслед за голосом.
class PlayerActivity : Activity(), Media.Listener {

    private fun dpi(v: Int) = (v * resources.displayMetrics.density).toInt()

    private lateinit var backdrop: CoverBackdrop
    private lateinit var content: LinearLayout
    private lateinit var cover: ImageView
    private lateinit var bigCover: ImageView
    private lateinit var titleView: TextView
    private lateinit var artistView: TextView
    private lateinit var lyricsView: LyricsView
    private lateinit var emptyBox: LinearLayout
    private lateinit var emptyText: TextView
    private lateinit var seek: SeekView
    private lateinit var timeL: TextView
    private lateinit var timeR: TextView
    private lateinit var play: IconView

    private var lastTitle = ""
    private var lastSecL = -1L
    private var lastSecR = -1L
    private var running = false

    private fun rounded(r: Float) = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, r)
        }
    }

    private fun cover(radiusDp: Float): ImageView = ImageView(this).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        setBackgroundColor(0xFF333333.toInt())
        clipToOutline = true
        outlineProvider = rounded(radiusDp * resources.displayMetrics.density)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        backdrop = CoverBackdrop(this, blurDp = 34f, dim = 0x80000000.toInt())
        root.addView(backdrop, FrameLayout.LayoutParams(-1, -1))

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(22), dpi(52), dpi(22), dpi(36))
        }
        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        root.setOnApplyWindowInsetsListener { _, insets ->
            content.setPadding(
                dpi(22), insets.systemWindowInsetTop + dpi(12),
                dpi(22), insets.systemWindowInsetBottom + dpi(16)
            )
            insets
        }

        // заголовок: обложка и названия
        cover = cover(16f)
        titleView = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        artistView = TextView(this).apply {
            setTextColor(0xFFBBBBBB.toInt()); textSize = 14f
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        val names = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            addView(titleView); addView(artistView)
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(cover, LinearLayout.LayoutParams(dpi(64), dpi(64)))
            addView(names, LinearLayout.LayoutParams(0, dpi(64), 1f).apply { setMargins(dpi(14), 0, 0, 0) })
        }
        content.addView(head, LinearLayout.LayoutParams(-1, dpi(64)))

        // слова песни или большая обложка, если слов нет
        lyricsView = LyricsView(this).apply {
            textSp = Prefs.getInt(this@PlayerActivity, Prefs.LYR_SIZE).toFloat()
            fillWords = Prefs.get(this@PlayerActivity, Prefs.WAVE)
            blurOn = Prefs.get(this@PlayerActivity, Prefs.LYR_BLUR)
            onLineClick = { t -> Media.controller?.transportControls?.seekTo((t * 1000).toLong()) }
        }

        bigCover = cover(28f)
        emptyText = TextView(this).apply {
            setTextColor(0xFFAAAAAA.toInt()); textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, dpi(18), 0, 0)
        }
        emptyBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(bigCover, LinearLayout.LayoutParams(dpi(260), dpi(260)))
            addView(emptyText)
        }
        val mid = FrameLayout(this)
        mid.addView(lyricsView, FrameLayout.LayoutParams(-1, -1))
        mid.addView(emptyBox, FrameLayout.LayoutParams(-1, -1))
        content.addView(mid, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, dpi(8), 0, dpi(8)) })

        // перемотка
        timeL = TextView(this).apply { setTextColor(0xFFBBBBBB.toInt()); textSize = 12f; text = "0:00" }
        timeR = TextView(this).apply {
            setTextColor(0xFFBBBBBB.toInt()); textSize = 12f; text = "0:00"; gravity = Gravity.END
        }
        seek = SeekView(this)
        seek.onSeek = { r ->
            if (Media.durationMs > 0) Media.controller?.transportControls?.seekTo((r * Media.durationMs).toLong())
        }
        val seekRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(timeL, LinearLayout.LayoutParams(dpi(42), -2))
            addView(seek, LinearLayout.LayoutParams(0, dpi(30), 1f))
            addView(timeR, LinearLayout.LayoutParams(dpi(42), -2))
        }
        content.addView(seekRow, LinearLayout.LayoutParams(-1, dpi(30)))

        // кнопки
        val prev = IconView(this, IconView.PREV)
        play = IconView(this, IconView.PLAY)
        val next = IconView(this, IconView.NEXT)
        prev.setOnClickListener { Media.controller?.transportControls?.skipToPrevious() }
        next.setOnClickListener { Media.controller?.transportControls?.skipToNext() }
        play.setOnClickListener {
            Media.controller?.let { if (Media.playing) it.transportControls.pause() else it.transportControls.play() }
        }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            for (b in listOf(prev, play, next)) {
                addView(b, LinearLayout.LayoutParams(dpi(78), dpi(64)).apply { setMargins(dpi(8), 0, dpi(8), 0) })
            }
        }
        content.addView(controls, LinearLayout.LayoutParams(-1, dpi(64)).apply { topMargin = dpi(8) })

        setContentView(root)
    }

    override fun onStart() {
        super.onStart()
        // настройки могли поменяться, пока плеер был закрыт
        lyricsView.textSp = Prefs.getInt(this, Prefs.LYR_SIZE).toFloat()
        lyricsView.fillWords = Prefs.get(this, Prefs.WAVE)
        lyricsView.blurOn = Prefs.get(this, Prefs.LYR_BLUR)
        Media.attach(this, this)
        running = true
        Choreographer.getInstance().postFrameCallback(frame)
    }

    override fun onStop() {
        running = false
        Choreographer.getInstance().removeFrameCallback(frame)
        Media.detach(this)
        super.onStop()
    }

    // ============================================================
    //  Данные
    // ============================================================
    override fun onMedia() {
        titleView.text = if (Media.controller == null) "Ничего не играет" else Media.title.ifEmpty { "Играет" }
        artistView.text = Media.artist
        val c = Media.cover
        cover.setImageBitmap(c)
        bigCover.setImageBitmap(c)
        backdrop.set(c, Prefs.get(this, Prefs.BLUR))
        val kind = if (Media.playing) IconView.PAUSE else IconView.PLAY
        if (play.kind != kind) {
            play.kind = kind
            play.invalidate()
        }
        if (Media.title != lastTitle) {
            lastTitle = Media.title
            titleView.alpha = 0f
            titleView.animate().alpha(1f).setDuration(350).start()
        }
        updateEmpty()
    }

    override fun onLyrics() {
        lyricsView.setLines(if (Prefs.get(this, Prefs.LYRICS)) Media.lyrics else null)
        updateEmpty()
    }

    private fun updateEmpty() {
        val has = Media.lyrics != null && Prefs.get(this, Prefs.LYRICS)
        lyricsView.visibility = if (has) View.VISIBLE else View.GONE
        emptyBox.visibility = if (has) View.GONE else View.VISIBLE
        emptyText.text = when {
            !Prefs.get(this, Prefs.LYRICS) -> "Слова песни выключены в настройках"
            Media.controller == null -> ""
            else -> "Слов для этого трека не нашлось"
        }
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    // Каждый кадр: время, ползунок и слова. Работает в такт экрану, поэтому заливка слов идёт плавно, без рывков
    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            val pos = Media.positionMs()
            val dur = Media.durationMs
            if (dur > 0) {
                if (!seek.dragging) seek.progress = (pos.toFloat() / dur).coerceIn(0f, 1f)
                val shownMs = if (seek.dragging) (seek.progress * dur).toLong() else pos
                val sl = shownMs / 1000
                if (sl != lastSecL) {
                    lastSecL = sl
                    timeL.text = fmt(shownMs)
                }
                val sr = dur / 1000
                if (sr != lastSecR) {
                    lastSecR = sr
                    timeR.text = fmt(dur)
                }
            }
            if (lyricsView.visibility == View.VISIBLE) lyricsView.update(pos / 1000.0 + 0.12)
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
}

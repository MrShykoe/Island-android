package com.mrsh1zuky.island

import android.animation.ObjectAnimator
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale
import kotlin.math.max

// Полноэкранный плеер: размытая обложка на фоне, перемотка, кнопки и живые слова песни.
class PlayerActivity : Activity(), Media.Listener {

    private val handler = Handler(Looper.getMainLooper())
    private fun dpi(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dp(v: Float) = v * resources.displayMetrics.density

    private lateinit var bg: ImageView
    private lateinit var content: LinearLayout
    private lateinit var cover: ImageView
    private lateinit var bigCover: ImageView
    private lateinit var titleView: TextView
    private lateinit var artistView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var linesBox: LinearLayout
    private lateinit var emptyBox: LinearLayout
    private lateinit var emptyText: TextView
    private lateinit var seek: SeekView
    private lateinit var timeL: TextView
    private lateinit var timeR: TextView
    private lateinit var play: IconView

    private val lineViews = ArrayList<WaveText>()
    private var shownLyrics: List<Media.Line>? = null
    private var curIdx = -2
    private var ww: WordWave? = null
    private var lastTitle = ""

    private fun rounded(r: Float) = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, r)
        }
    }

    private fun cover(sizeDp: Int, radiusDp: Float): ImageView = ImageView(this).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        setBackgroundColor(0xFF333333.toInt())
        clipToOutline = true
        outlineProvider = rounded(radiusDp * resources.displayMetrics.density)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        bg = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY
            alpha = 0f
        }
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(22), dpi(52), dpi(22), dpi(36))
        }
        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        root.setOnApplyWindowInsetsListener { _, insets ->
            content.setPadding(
                dpi(22), insets.systemWindowInsetTop + dpi(12),
                dpi(22), insets.systemWindowInsetBottom + dpi(16)
            )
            insets
        }

        // заголовок: обложка и названия
        cover = cover(64, 16f)
        titleView = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        artistView = TextView(this).apply {
            setTextColor(0xFFAAAAAA.toInt()); textSize = 14f
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        val names = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            addView(titleView); addView(artistView)
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(cover, LinearLayout.LayoutParams(dpi(64), dpi(64)))
            addView(names, LinearLayout.LayoutParams(0, dpi(64), 1f).apply { setMargins(dpi(14), 0, 0, 0) })
        }
        content.addView(head, LinearLayout.LayoutParams(-1, dpi(64)))

        // слова песни или большая обложка, если слов нет
        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        linesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(linesBox, FrameLayout.LayoutParams(-1, -2))

        bigCover = cover(260, 28f)
        emptyText = TextView(this).apply {
            setTextColor(0xFF999999.toInt()); textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, dpi(18), 0, 0)
        }
        emptyBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(bigCover, LinearLayout.LayoutParams(dpi(260), dpi(260)))
            addView(emptyText)
        }
        val mid = FrameLayout(this)
        mid.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        mid.addView(emptyBox, FrameLayout.LayoutParams(-1, -1))
        content.addView(mid, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, dpi(8), 0, dpi(8)) })

        // перемотка
        timeL = TextView(this).apply { setTextColor(0xFFAAAAAA.toInt()); textSize = 12f; text = "0:00" }
        timeR = TextView(this).apply {
            setTextColor(0xFFAAAAAA.toInt()); textSize = 12f; text = "0:00"; gravity = Gravity.END
        }
        seek = SeekView(this)
        seek.onSeek = { r ->
            if (Media.durationMs > 0) Media.controller?.transportControls?.seekTo((r * Media.durationMs).toLong())
        }
        val seekRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(timeL, LinearLayout.LayoutParams(dpi(42), -2))
            addView(seek, LinearLayout.LayoutParams(0, dpi(30), 1f))
            addView(timeR, LinearLayout.LayoutParams(dpi(42), -2))
        }
        content.addView(seekRow, LinearLayout.LayoutParams(-1, dpi(30)))

        // кнопки
        val prev = IconView(this, IconView.PREV)
        play = IconView(this, IconView.PLAY)
        val next = IconView(this, IconView.NEXT)
        prev.setOnClickListener { Media.controller?.transportControls?.skipToPrevious() }
        next.setOnClickListener { Media.controller?.transportControls?.skipToNext() }
        play.setOnClickListener {
            Media.controller?.let { if (Media.playing) it.transportControls.pause() else it.transportControls.play() }
        }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            for (b in listOf(prev, play, next)) {
                addView(b, LinearLayout.LayoutParams(dpi(78), dpi(64)).apply { setMargins(dpi(8), 0, dpi(8), 0) })
            }
        }
        content.addView(controls, LinearLayout.LayoutParams(-1, dpi(64)).apply { topMargin = dpi(8) })

        setContentView(root)
    }

    override fun onStart() {
        super.onStart()
        Media.attach(this, this)
        handler.post(ticker)
    }

    override fun onStop() {
        handler.removeCallbacksAndMessages(null)
        Media.detach(this)
        super.onStop()
    }

    // ============================================================
    //  Данные
    // ============================================================
    override fun onMedia() {
        titleView.text = if (Media.controller == null) "Ничего не играет" else Media.title.ifEmpty { "Играет" }
        artistView.text = Media.artist
        val c = Media.cover
        cover.setImageBitmap(c)
        bigCover.setImageBitmap(c)
        setBlur(c)
        val kind = if (Media.playing) IconView.PAUSE else IconView.PLAY
        if (play.kind != kind) {
            play.kind = kind
            play.invalidate()
        }
        if (Media.title != lastTitle) {
            lastTitle = Media.title
            titleView.alpha = 0f
            titleView.animate().alpha(1f).setDuration(350).start()
        }
        updateEmpty()
    }

    override fun onLyrics() {
        rebuildLines()
        updateEmpty()
    }

    private fun updateEmpty() {
        val has = Media.lyrics != null && Prefs.get(this, Prefs.LYRICS)
        scroll.visibility = if (has) View.VISIBLE else View.GONE
        emptyBox.visibility = if (has) View.GONE else View.VISIBLE
        emptyText.text = when {
            !Prefs.get(this, Prefs.LYRICS) -> "Слова песни выключены в настройках"
            Media.controller == null -> ""
            else -> "Слов для этого трека не нашлось"
        }
    }

    private fun setBlur(c: Bitmap?) {
        if (c == null || !Prefs.get(this, Prefs.BLUR)) {
            bg.animate().alpha(0f).setDuration(400).start()
            return
        }
        try {
            val soft = if (c.config == Bitmap.Config.HARDWARE) c.copy(Bitmap.Config.ARGB_8888, false) else c
            bg.setImageBitmap(Bitmap.createScaledBitmap(soft, 12, 12, true))
            bg.setColorFilter(Color.argb(150, 0, 0, 0), PorterDuff.Mode.SRC_ATOP)
            bg.animate().cancel()
            bg.alpha = 0f
            bg.animate().alpha(1f).setDuration(700).start()
        } catch (e: Exception) {
            bg.alpha = 0f
        }
    }

    // ============================================================
    //  Слова песни
    // ============================================================
    private fun rebuildLines() {
        linesBox.removeAllViews()
        lineViews.clear()
        curIdx = -2
        ww = null
        val lines = Media.lyrics
        shownLyrics = lines
        if (lines == null) return
        linesBox.addView(View(this), LinearLayout.LayoutParams(-1, dpi(140)))
        for (l in lines) {
            val tv = WaveText(this).apply {
                text = if (l.s.isBlank()) "..." else l.s
                setTextColor(Color.WHITE)
                textSize = 22f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                align = 2
                alpha = 0.35f
                setPadding(0, dpi(9), 0, dpi(9))
            }
            lineViews.add(tv)
            linesBox.addView(tv, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        linesBox.addView(View(this), LinearLayout.LayoutParams(-1, dpi(140)))
    }

    private fun highlight(idx: Int) {
        val lines = Media.lyrics ?: return
        for (i in lineViews.indices) {
            val v = lineViews[i]
            v.wave = -1f
            val on = i == idx
            v.animate().alpha(if (on) 1f else 0.35f).scaleX(if (on) 1.04f else 1f).scaleY(if (on) 1.04f else 1f)
                .setDuration(300).start()
        }
        ww = null
        if (idx in lineViews.indices) {
            val v = lineViews[idx]
            if (Prefs.get(this, Prefs.WAVE) && !lines[idx].s.isBlank()) {
                val avail = scroll.width - dp(8f)
                val w = WordWave(lines[idx].s, lines[idx].t, if (idx + 1 < lines.size) lines[idx + 1].t else lines[idx].t + 4, v.paint)
                if (w.width < avail) {
                    ww = w
                    v.textW = w.width
                    v.wave = 0f
                }
            }
            val target = max(0, v.top + v.height / 2 - scroll.height / 2)
            ObjectAnimator.ofInt(scroll, "scrollY", scroll.scrollY, target).apply {
                duration = 450
                interpolator = DecelerateInterpolator()
            }.start()
        }
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private val ticker = object : Runnable {
        override fun run() {
            val pos = Media.positionMs()
            val dur = Media.durationMs
            if (dur > 0) {
                if (!seek.dragging) seek.progress = (pos.toFloat() / dur).coerceIn(0f, 1f)
                timeL.text = fmt(if (seek.dragging) (seek.progress * dur).toLong() else pos)
                timeR.text = fmt(dur)
            }
            val lines = Media.lyrics
            if (lines != null && lines === shownLyrics) {
                val t = pos / 1000.0 + 0.15
                var idx = -1
                for (i in lines.indices) {
                    if (lines[i].t <= t) idx = i else break
                }
                if (idx != curIdx) {
                    curIdx = idx
                    highlight(idx)
                }
                val w = ww
                if (w != null && curIdx in lineViews.indices) {
                    val v = lineViews[curIdx]
                    v.wave = w.xAt(t).coerceIn(0f, v.textW)
                    v.invalidate()
                }
            }
            handler.postDelayed(this, 40)
        }
    }
}

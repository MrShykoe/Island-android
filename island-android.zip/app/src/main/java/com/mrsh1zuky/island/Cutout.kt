package com.mrsh1zuky.island

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.view.Display

// Где находится вырез камеры. У S24+ камера по центру сверху: остров обходит её,
// а текст и обложка не прячутся под ней.
object Cutout {
    class Info(val gap: Float, val centerY: Float, val bottom: Float)

    fun read(ctx: Context): Info {
        val d = ctx.resources.displayMetrics.density
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val dm = ctx.getSystemService(DisplayManager::class.java)
                val rect = dm.getDisplay(Display.DEFAULT_DISPLAY)?.cutout?.boundingRectTop
                if (rect != null && !rect.isEmpty) {
                    return Info(
                        (rect.width() + 14 * d).coerceIn(24 * d, 60 * d),
                        rect.centerY().toFloat(),
                        rect.bottom.toFloat()
                    )
                }
            }
        } catch (e: Exception) {
        }
        // запасной вариант: камера по центру сверху
        return Info(30 * d, 16 * d, 27 * d)
    }
}

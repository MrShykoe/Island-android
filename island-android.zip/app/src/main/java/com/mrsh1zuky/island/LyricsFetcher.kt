package com.mrsh1zuky.island

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

// Слова песен: сначала lrclib.net (точный поиск и обычный поиск), потом, если разрешено, NetEase.
// Наружу уходят только название и исполнитель трека.
object LyricsFetcher {

    private const val UA = "Island/1.0 (personal android island)"
    private const val BROWSER = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"

    private fun http(url: String, ua: String, referer: String? = null): String? {
        var c: HttpURLConnection? = null
        return try {
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 6000
            c.readTimeout = 6000
            c.setRequestProperty("User-Agent", ua)
            if (referer != null) c.setRequestProperty("Referer", referer)
            if (c.responseCode != 200) null else c.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            null
        } finally {
            c?.disconnect()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private val junk1 = Regex("""\s*[\(\[].*?[\)\]]""")
    private val junk2 = Regex("""\s+(feat\.?|ft\.?)\s.*$""", RegexOption.IGNORE_CASE)
    private val artistSplit = Regex(""",|&|\bfeat\.?\b|\bft\.?\b""", RegexOption.IGNORE_CASE)

    private fun stripJunk(t: String) = junk2.replace(junk1.replace(t, ""), "").trim()
    private fun cleanArtist(a: String) = a.replace(" - Topic", "").split(artistSplit)[0].trim()

    // Из «Исполнитель - Название (Official Video)» с YouTube нужно уметь достать настоящую пару
    private fun candidates(title: String, artist: String): List<Pair<String, String>> {
        val res = ArrayList<Pair<String, String>>()
        val a = cleanArtist(artist)
        val parts = title.split(" - ").filter { it.isNotBlank() }
        if (parts.size >= 2) {
            if (a.isNotEmpty() && parts[0].contains(a, ignoreCase = true)) res.add(Pair(a, stripJunk(parts[1])))
            res.add(Pair(stripJunk(parts[0]), stripJunk(parts[1])))
            res.add(Pair(a, stripJunk(parts[0])))
        }
        res.add(Pair(a, stripJunk(title)))
        return res.filter { it.second.isNotEmpty() }.distinct().take(4)
    }

    private val stamp = Regex("""\[(\d+):(\d+(?:\.\d+)?)\]""")
    private val credit = Regex("""^(作词|作曲|编曲|制作|混音|母带|歌手|Lyrics by|Composed by|Arranged by|Produced by)""", RegexOption.IGNORE_CASE)

    private fun parseLrc(lrc: String): List<Media.Line> {
        val res = ArrayList<Media.Line>()
        for (raw in lrc.split("\n")) {
            val ms = stamp.findAll(raw).toList()
            if (ms.isEmpty()) continue
            val text = stamp.replace(raw, "").trim()
            if (credit.containsMatchIn(text)) continue
            for (m in ms) {
                val t = m.groupValues[1].toInt() * 60 + m.groupValues[2].toDouble()
                res.add(Media.Line(t, text))
            }
        }
        res.sortBy { it.t }
        return res
    }

    private fun lrclibGet(a: String, t: String, dur: Double): String? {
        val q = "artist_name=${enc(a)}&track_name=${enc(t)}" + if (dur > 1) "&duration=${Math.round(dur)}" else ""
        val body = http("https://lrclib.net/api/get?$q", UA) ?: return null
        val s = JSONObject(body).optString("syncedLyrics", "")
        return if (s.isBlank()) null else s
    }

    private fun lrclibSearch(query: String, dur: Double): String? {
        val body = http("https://lrclib.net/api/search?$query", UA) ?: return null
        val arr = JSONArray(body)
        var best: String? = null
        var bestDiff = Double.MAX_VALUE
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val s = o.optString("syncedLyrics", "")
            if (s.isBlank()) continue
            val d = if (dur > 1 && o.has("duration")) abs(o.optDouble("duration", 0.0) - dur) else 0.0
            if (dur > 1 && d > 8) continue // другая версия трека
            if (d < bestDiff) {
                bestDiff = d
                best = s
            }
        }
        return best
    }

    private fun netEase(artist: String, title: String, dur: Double): String? {
        val body = http(
            "https://music.163.com/api/search/get/web?type=1&offset=0&limit=6&s=" + enc("$artist $title".trim()),
            BROWSER, "https://music.163.com/"
        ) ?: return null
        val songs = JSONObject(body).optJSONObject("result")?.optJSONArray("songs") ?: return null
        var id = 0L
        for (i in 0 until songs.length()) {
            val song = songs.getJSONObject(i)
            val name = song.optString("name", "")
            var artistOk = artist.isEmpty()
            val ar = song.optJSONArray("artists")
            if (ar != null) {
                for (j in 0 until ar.length()) {
                    val n = ar.getJSONObject(j).optString("name", "")
                    if (artist.isNotEmpty() && n.isNotEmpty() &&
                        (n.contains(artist, true) || artist.contains(n, true))
                    ) artistOk = true
                }
            }
            val nameOk = name.contains(title, true) || (name.isNotEmpty() && title.contains(name, true))
            var durOk = true
            if (dur > 1 && song.has("duration")) durOk = abs(song.optDouble("duration", 0.0) / 1000.0 - dur) <= 8
            if (artistOk && nameOk && durOk) {
                id = song.optLong("id", 0L)
                break
            }
        }
        if (id == 0L) return null
        val lb = http("https://music.163.com/api/song/lyric?id=$id&lv=-1&kv=-1&tv=-1", BROWSER, "https://music.163.com/")
            ?: return null
        val s = JSONObject(lb).optJSONObject("lrc")?.optString("lyric", "") ?: ""
        return if (s.isBlank()) null else s
    }

    fun fetch(title: String, artist: String, durSec: Double, extra: Boolean): List<Media.Line>? {
        val cands = candidates(title, artist)
        var lrc: String? = null
        for ((a, t) in cands) {
            try {
                lrc = lrclibGet(a, t, durSec)
                if (lrc == null) lrc = lrclibSearch("track_name=${enc(t)}&artist_name=${enc(a)}", durSec)
                if (lrc == null && a.isNotEmpty()) lrc = lrclibSearch("q=${enc("$a $t")}", durSec)
            } catch (e: Exception) {
            }
            if (lrc != null) break
        }
        if (lrc == null && extra) {
            for ((a, t) in cands.take(2)) {
                try {
                    lrc = netEase(a, t, durSec)
                } catch (e: Exception) {
                }
                if (lrc != null) break
            }
        }
        if (lrc == null) return null
        val lines = parseLrc(lrc)
        return if (lines.size > 2) lines else null
    }
}

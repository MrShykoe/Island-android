package com.mrsh1zuky.island

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs
import kotlin.math.max

// Слова песен: сначала lrclib.net (точный поиск и обычный поиск), потом, если разрешено, NetEase.
// Наружу уходят только название и исполнитель трека.
object LyricsFetcher {

    private const val UA = "Island/1.0 (personal android island)"
    private const val BROWSER = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"

    private fun http(url: String, ua: String, referer: String? = null): String? {
        var c: HttpURLConnection? = null
        return try {
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 6000
            c.readTimeout = 6000
            c.setRequestProperty("User-Agent", ua)
            if (referer != null) c.setRequestProperty("Referer", referer)
            if (c.responseCode != 200) null else c.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            null
        } finally {
            c?.disconnect()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private val junk1 = Regex("""\s*[\(\[].*?[\)\]]""")
    private val junk2 = Regex("""\s+(feat\.?|ft\.?)\s.*$""", RegexOption.IGNORE_CASE)
    private val artistSplit = Regex(""",|&|\bfeat\.?\b|\bft\.?\b""", RegexOption.IGNORE_CASE)

    private fun stripJunk(t: String) = junk2.replace(junk1.replace(t, ""), "").trim()
    private fun cleanArtist(a: String) = a.replace(" - Topic", "").split(artistSplit)[0].trim()

    // Из «Исполнитель - Название (Official Video)» с YouTube нужно уметь достать настоящую пару
    private fun candidates(title: String, artist: String): List<Pair<String, String>> {
        val res = ArrayList<Pair<String, String>>()
        val a = cleanArtist(artist)
        val parts = title.split(" - ").filter { it.isNotBlank() }
        if (parts.size >= 2) {
            if (a.isNotEmpty() && parts[0].contains(a, ignoreCase = true)) res.add(Pair(a, stripJunk(parts[1])))
            res.add(Pair(stripJunk(parts[0]), stripJunk(parts[1])))
            res.add(Pair(a, stripJunk(parts[0])))
        }
        res.add(Pair(a, stripJunk(title)))
        return res.filter { it.second.isNotEmpty() }.distinct().take(4)
    }

    private val stamp = Regex("""\[(\d+):(\d+(?:\.\d+)?)\]""")
    private val wtag = Regex("""<(\d+):(\d+(?:\.\d+)?)>""")
    private val credit = Regex("""^(作词|作曲|编曲|制作|混音|母带|歌手|Lyrics by|Composed by|Arranged by|Produced by)""", RegexOption.IGNORE_CASE)

    private class Seg(val t: Double, val c0: Int, val c1: Int)

    // Строка с пословными метками вида <00:12.34>слово (enhanced LRC): достаём текст и времена слов
    private fun withWords(raw: String): Pair<String, List<Media.Word>?> {
        val ms = wtag.findAll(raw).toList()
        if (ms.size < 2) return Pair(wtag.replace(raw, "").trim(), null)
        val sb = StringBuilder()
        if (ms[0].range.first > 0) sb.append(raw.substring(0, ms[0].range.first))
        val segs = ArrayList<Seg>()
        for ((i, m) in ms.withIndex()) {
            val end = if (i + 1 < ms.size) ms[i + 1].range.first else raw.length
            val c0 = sb.length
            sb.append(raw.substring(m.range.last + 1, end))
            segs.add(Seg(m.groupValues[1].toInt() * 60 + m.groupValues[2].toDouble(), c0, sb.length))
        }
        val clean = sb.toString()
        val lead = clean.length - clean.trimStart().length
        val text = clean.trim()
        val words = ArrayList<Media.Word>()
        for ((i, sg) in segs.withIndex()) {
            var a = sg.c0
            var b = sg.c1
            while (a < b && clean[a].isWhitespace()) a++
            while (b > a && clean[b - 1].isWhitespace()) b--
            if (a >= b) continue
            val t1 = if (i + 1 < segs.size) segs[i + 1].t else sg.t + 0.6
            words.add(
                Media.Word(
                    sg.t, max(t1, sg.t + 0.05),
                    (a - lead).coerceIn(0, text.length), (b - lead).coerceIn(0, text.length)
                )
            )
        }
        return Pair(text, if (words.isEmpty()) null else words)
    }

    private fun parseLrc(lrc: String): List<Media.Line> {
        val res = ArrayList<Media.Line>()
        for (raw in lrc.split("\n")) {
            val ms = stamp.findAll(raw).toList()
            if (ms.isEmpty()) continue
            val (text, words) = withWords(stamp.replace(raw, ""))
            if (credit.containsMatchIn(text)) continue
            for (m in ms) {
                val t = m.groupValues[1].toInt() * 60 + m.groupValues[2].toDouble()
                res.add(Media.Line(t, text, words))
            }
        }
        res.sortBy { it.t }
        linkEnds(res)
        return res
    }

    private fun linkEnds(lines: List<Media.Line>) {
        for (i in lines.indices) {
            lines[i].tNext = if (i + 1 < lines.size) lines[i + 1].t else lines[i].t + 5.0
        }
    }

    // NetEase yrc / klyric: [началоМс,длительностьМс](началоСловаМс,длительностьМс,0)слово...
    private val yrcLine = Regex("""^\[(\d+),(\d+)\](.*)$""")
    private val yrcWord = Regex("""\((\d+),(\d+),-?\d+\)([^(]*)""")

    private fun parseYrc(yrc: String): List<Media.Line> {
        val res = ArrayList<Media.Line>()
        for (raw in yrc.split("\n")) {
            val m = yrcLine.find(raw.trim()) ?: continue
            val ls = m.groupValues[1].toDouble() / 1000.0
            val parts = yrcWord.findAll(m.groupValues[3]).toList()
            if (parts.isEmpty()) continue
            val sb = StringBuilder()
            val words = ArrayList<Media.Word>()
            for (p in parts) {
                val raw0 = p.groupValues[3]
                val seg = raw0.trim()
                if (seg.isEmpty()) {
                    sb.append(raw0)
                    continue
                }
                if (sb.isNotEmpty() && !sb.last().isWhitespace() && raw0.first().isWhitespace()) sb.append(' ')
                val c0 = sb.length
                sb.append(seg)
                if (raw0.last().isWhitespace()) sb.append(' ')
                var ws = p.groupValues[1].toDouble() / 1000.0
                if (ws < ls - 0.05) ws += ls // в klyric время слова задано смещением от начала строки
                words.add(Media.Word(ws, ws + max(0.05, p.groupValues[2].toDouble() / 1000.0), c0, c0 + seg.length))
            }
            val text = sb.toString().trim()
            if (text.isEmpty() || credit.containsMatchIn(text)) continue
            res.add(Media.Line(ls, text, words.map { Media.Word(it.t0, it.t1, it.c0.coerceAtMost(text.length), it.c1.coerceAtMost(text.length)) }))
        }
        res.sortBy { it.t }
        linkEnds(res)
        return res
    }

    private fun lrclibGet(a: String, t: String, dur: Double): String? {
        val q = "artist_name=${enc(a)}&track_name=${enc(t)}" + if (dur > 1) "&duration=${Math.round(dur)}" else ""
        val body = http("https://lrclib.net/api/get?$q", UA) ?: return null
        val s = JSONObject(body).optString("syncedLyrics", "")
        return if (s.isBlank()) null else s
    }

    private fun lrclibSearch(query: String, dur: Double): String? {
        val body = http("https://lrclib.net/api/search?$query", UA) ?: return null
        val arr = JSONArray(body)
        var best: String? = null
        var bestDiff = Double.MAX_VALUE
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val s = o.optString("syncedLyrics", "")
            if (s.isBlank()) continue
            val d = if (dur > 1 && o.has("duration")) abs(o.optDouble("duration", 0.0) - dur) else 0.0
            if (dur > 1 && d > 8) continue // другая версия трека
            if (d < bestDiff) {
                bestDiff = d
                best = s
            }
        }
        return best
    }

    // Возвращает (пословные, построчные). Любое из двух может быть null.
    private fun netEase(artist: String, title: String, dur: Double): Pair<String?, String?>? {
        val body = http(
            "https://music.163.com/api/search/get/web?type=1&offset=0&limit=6&s=" + enc("$artist $title".trim()),
            BROWSER, "https://music.163.com/"
        ) ?: return null
        val songs = JSONObject(body).optJSONObject("result")?.optJSONArray("songs") ?: return null
        var id = 0L
        for (i in 0 until songs.length()) {
            val song = songs.getJSONObject(i)
            val name = song.optString("name", "")
            var artistOk = artist.isEmpty()
            val ar = song.optJSONArray("artists")
            if (ar != null) {
                for (j in 0 until ar.length()) {
                    val n = ar.getJSONObject(j).optString("name", "")
                    if (artist.isNotEmpty() && n.isNotEmpty() &&
                        (n.contains(artist, true) || artist.contains(n, true))
                    ) artistOk = true
                }
            }
            val nameOk = name.contains(title, true) || (name.isNotEmpty() && title.contains(name, true))
            var durOk = true
            if (dur > 1 && song.has("duration")) durOk = abs(song.optDouble("duration", 0.0) / 1000.0 - dur) <= 8
            if (artistOk && nameOk && durOk) {
                id = song.optLong("id", 0L)
                break
            }
        }
        if (id == 0L) return null
        val lb = http(
            "https://music.163.com/api/song/lyric?id=$id&lv=-1&kv=-1&tv=-1&yv=-1&rv=-1",
            BROWSER, "https://music.163.com/"
        ) ?: return null
        val o = JSONObject(lb)
        val lrc = o.optJSONObject("lrc")?.optString("lyric", "")?.takeIf { it.isNotBlank() }
        val yrc = o.optJSONObject("yrc")?.optString("lyric", "")?.takeIf { it.isNotBlank() }
            ?: o.optJSONObject("klyric")?.optString("lyric", "")?.takeIf { it.contains("](") }
        return Pair(yrc, lrc)
    }

    // Сначала быстро отдаём построчные слова (lrclib), потом, если NetEase знает времена отдельных слов, присылаем улучшенный вариант.
    fun fetch(title: String, artist: String, durSec: Double, extra: Boolean, done: (List<Media.Line>?) -> Unit) {
        val cands = candidates(title, artist)
        var lrc: String? = null
        for ((a, t) in cands) {
            try {
                lrc = lrclibGet(a, t, durSec)
                if (lrc == null) lrc = lrclibSearch("track_name=${enc(t)}&artist_name=${enc(a)}", durSec)
                if (lrc == null && a.isNotEmpty()) lrc = lrclibSearch("q=${enc("$a $t")}", durSec)
            } catch (e: Exception) {
            }
            if (lrc != null) break
        }
        var lines: List<Media.Line>? = null
        if (lrc != null) {
            val parsed = parseLrc(lrc)
            if (parsed.size > 2) lines = parsed
        }
        val hasRealWords = lines?.any { it.realWords != null } == true
        done(lines)
        if (!extra || hasRealWords) return

        for ((a, t) in cands.take(2)) {
            try {
                val r = netEase(a, t, durSec) ?: continue
                val yrcLines = r.first?.let { parseYrc(it) }
                if (yrcLines != null && yrcLines.size > 2) {
                    done(yrcLines)
                    return
                }
                if (lines == null) {
                    val plain = r.second?.let { parseLrc(it) }
                    if (plain != null && plain.size > 2) {
                        done(plain)
                        return
                    }
                }
            } catch (e: Exception) {
            }
        }
    }
}

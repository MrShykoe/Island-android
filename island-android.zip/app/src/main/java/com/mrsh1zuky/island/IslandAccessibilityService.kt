package com.mrsh1zuky.island

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

// Служба спец. возможностей только даёт окну острова тип ACCESSIBILITY_OVERLAY, который лежит выше статус-бара.
// Она не читает экран и ничего не нажимает (canRetrieveWindowContent = false, события не обрабатываются).
class IslandAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: IslandAccessibilityService? = null
            private set

        val connected get() = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        // запасной вариант (обычный оверлей) больше не нужен
        stopService(Intent(this, IslandService::class.java))
        if (Prefs.get(this, Prefs.ENABLED)) {
            IslandHost.show(this, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        IslandHost.hide(this)
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        IslandHost.hide(this)
        instance = null
        super.onDestroy()
    }
}

package com.mrsh1zuky.island

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ============================================================
//  Сам остров: чёрная пилюля у камеры, раскрывается пружиной
// ============================================================
class IslandView(ctx: Context) : FrameLayout(ctx) {

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density
    private fun dpi(v: Int) = (v * density).toInt()

    // ---------- пружина ----------
    private class Spring(var p: Double) {
        var v = 0.0
        var t = p
        fun step(dt: Double) {
            val a = -170.0 * (p - t) - 13.0 * v // меньше второе число = больше «желе»
            v += a * dt
            p += v * dt
        }
        fun settled() = abs(p - t) < 0.4 && abs(v) < 0.4
    }

    private val miniH = dp(36f)
    private var miniW = dp(150f)
    private val fullH = dp(184f)
    private val fullW: Float
        get() = min(dp(360f), resources.displayMetrics.widthPixels - dp(24f))

    private val sw = Spring(miniW.toDouble())
    private val sh = Spring(miniH.toDouble())
    private val sr = Spring((miniH / 2).toDouble())

    private val bg = GradientDrawable().apply {
        setColor(Color.BLACK)
        cornerRadius = miniH / 2
    }

    // ---------- состояние ----------
    private var expanded = false
    private var lastTitle = ""
    private var skipDir = 1
    private var skipAt = 0L
    private var idleMode = true
    private val handler = Handler(Looper.getMainLooper())
    private val tracker = MediaTracker(ctx) { refresh() }

    // ---------- свёрнутый вид ----------
    private val bgImage = ImageView(ctx).apply {
        scaleType = ImageView.ScaleType.FIT_XY
        alpha = 0f
    }
    private val miniCover = makeCover(22f, 11f)
    private val miniTitle = TextView(ctx).apply {
        setTextColor(Color.WHITE)
        textSize = 12f
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }
    private val miniEq = EqView(ctx)
    private val mini = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dpi(8), 0, dpi(14), 0)
    }

    // ---------- развёрнутый вид ----------
    private val fullCover = makeCover(64f, 16f)
    private val fullTitle = TextView(ctx).apply {
        setTextColor(Color.WHITE)
        textSize = 16f
        setTypeface(typeface, Typeface.BOLD)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }
    private val fullArtist = TextView(ctx).apply {
        setTextColor(0xFF999999.toInt())
        textSize = 13f
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }
    private val fullEq = EqView(ctx)
    private val timeL = TextView(ctx).apply {
        setTextColor(0xFF888888.toInt()); textSize = 11f; text = "0:00"
    }
    private val timeR = TextView(ctx).apply {
        setTextColor(0xFF888888.toInt()); textSize = 11f; text = "0:00"; gravity = Gravity.END
    }
    private val seek = SeekView(ctx)
    private val prev = IconView(ctx, IconView.PREV)
    private val play = IconView(ctx, IconView.PLAY)
    private val next = IconView(ctx, IconView.NEXT)
    private val full = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dpi(18), dpi(16), dpi(18), dpi(8))
    }

    init {
        background = bg
        clipToOutline = true
        outlineProvider = ViewOutlineProvider.BACKGROUND

        // свёрнутый
        mini.addView(miniCover, LinearLayout.LayoutParams(dpi(22), dpi(22)))
        mini.addView(miniTitle, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dpi(8), 0, dpi(8), 0)
        })
        mini.addView(miniEq, LinearLayout.LayoutParams(dpi(27), dpi(18)))

        // развёрнутый: верхний ряд
        val textCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            addView(fullTitle)
            addView(fullArtist)
        }
        val top = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(fullCover, LinearLayout.LayoutParams(dpi(64), dpi(64)))
            addView(textCol, LinearLayout.LayoutParams(0, dpi(64), 1f).apply { setMargins(dpi(14), 0, dpi(10), 0) })
            addView(fullEq, LinearLayout.LayoutParams(dpi(27), dpi(18)))
        }
        // ползунок
        val seekRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(timeL, LinearLayout.LayoutParams(dpi(38), ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(seek, LinearLayout.LayoutParams(0, dpi(26), 1f))
            addView(timeR, LinearLayout.LayoutParams(dpi(38), ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        // кнопки по центру
        val controls = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            for (b in listOf(prev, play, next)) {
                addView(b, LinearLayout.LayoutParams(dpi(52), dpi(46)).apply { setMargins(dpi(6), 0, dpi(6), 0) })
            }
        }
        full.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpi(64)))
        full.addView(seekRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpi(26)).apply {
            topMargin = dpi(10)
        })
        full.addView(controls, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpi(46)))

        addView(bgImage)
        addView(mini)
        addView(full)
        full.alpha = 0f
        full.visibility = INVISIBLE

        // действия
        prev.setOnClickListener {
            skipDir = -1; skipAt = System.currentTimeMillis()
            tracker.controller?.transportControls?.skipToPrevious()
        }
        next.setOnClickListener {
            skipDir = 1; skipAt = System.currentTimeMillis()
            tracker.controller?.transportControls?.skipToNext()
        }
        play.setOnClickListener {
            tracker.controller?.let {
                if (tracker.playing) it.transportControls.pause() else it.transportControls.play()
            }
        }
        seek.onSeek = { r ->
            if (tracker.durationMs > 0) {
                tracker.controller?.transportControls?.seekTo((r * tracker.durationMs).toLong())
            }
        }
        setOnClickListener { if (!expanded) setExpanded(true) }
    }

    private fun makeCover(sizeDp: Float, radiusDp: Float): ImageView {
        val r = radiusDp * density
        return ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF333333.toInt())
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, r)
                }
            }
        }
    }

    // ============================================================
    //  Анимация размера (пружина)
    // ============================================================
    private var looping = false
    private var lastNs = 0L
    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            val dt = min(0.032, (frameTimeNanos - lastNs) / 1e9)
            lastNs = frameTimeNanos
            sw.step(dt); sh.step(dt); sr.step(dt)
            applySize()
            if (sw.settled() && sh.settled() && sr.settled()) {
                sw.p = sw.t; sh.p = sh.t; sr.p = sr.t
                applySize()
                looping = false
            } else {
                Choreographer.getInstance().postFrameCallback(this)
            }
        }
    }

    private fun go(w: Float, h: Float, r: Float) {
        sw.t = w.toDouble(); sh.t = h.toDouble(); sr.t = r.toDouble()
        if (!looping) {
            looping = true
            lastNs = System.nanoTime()
            Choreographer.getInstance().postFrameCallback(frame)
        }
    }

    private fun applySize() {
        val h = max(1.0, sh.p)
        bg.cornerRadius = sr.p.toFloat().coerceIn(0f, (h / 2).toFloat())
        invalidateOutline()
        requestLayout()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = max(1, sw.p.toInt())
        val h = max(1, sh.p.toInt())
        setMeasuredDimension(w, h)
        bgImage.measure(exact(w), exact(h))
        // содержимое всегда выкладывается на итоговую ширину: так текст не дёргается, пока остров растёт
        mini.measure(exact(miniW.toInt()), exact(miniH.toInt()))
        full.measure(exact(fullW.toInt()), exact(fullH.toInt()))
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        bgImage.layout(0, 0, w, h)
        centerIn(mini, w, h)
        centerIn(full, w, h)
    }

    private fun centerIn(v: View, w: Int, h: Int) {
        val x = (w - v.measuredWidth) / 2
        val y = (h - v.measuredHeight) / 2
        v.layout(x, y, x + v.measuredWidth, y + v.measuredHeight)
    }

    private fun exact(px: Int) = MeasureSpec.makeMeasureSpec(px, MeasureSpec.EXACTLY)

    private fun fade(v: View, show: Boolean) {
        v.animate().cancel()
        if (show) {
            v.visibility = VISIBLE
            v.animate().alpha(1f).setDuration(260).start()
        } else {
            v.animate().alpha(0f).setDuration(120).withEndAction { v.visibility = INVISIBLE }.start()
        }
    }

    private fun setExpanded(on: Boolean) {
        if (expanded == on) return
        expanded = on
        if (on) go(fullW, fullH, dp(34f)) else go(miniW, miniH, miniH / 2)
        fade(full, on)
        fade(mini, !on)
        updateProgress()
    }

    // тап за пределами острова сворачивает его
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_OUTSIDE) setExpanded(false)
        return super.dispatchTouchEvent(ev)
    }

    // ============================================================
    //  Данные
    // ============================================================
    private fun clock(): String = SimpleDateFormat("HH:mm  EEE, d MMM", Locale("ru")).format(Date())

    private fun refresh() {
        val t = tracker
        val idle = t.hasAccess && t.controller == null
        idleMode = idle

        val miniText = when {
            !t.hasAccess -> "Нужен доступ к уведомлениям"
            idle -> clock()
            t.title.isEmpty() -> "Играет"
            else -> t.title
        }
        miniTitle.text = miniText
        fullTitle.text = if (idle) "Ничего не играет" else t.title.ifEmpty { "Играет" }
        fullArtist.text = if (idle) "" else t.artist

        // обложка и размытый фон
        val c = t.cover
        miniCover.visibility = if (idle) GONE else VISIBLE
        miniEq.visibility = if (idle) GONE else VISIBLE
        miniCover.setImageBitmap(c)
        fullCover.setImageBitmap(c)
        setBlurBackground(c)

        miniEq.playing = t.playing
        fullEq.playing = t.playing
        val newKind = if (t.playing) IconView.PAUSE else IconView.PLAY
        if (play.kind != newKind) {
            play.kind = newKind
            play.invalidate()
            pop(play)
        }

        // ширина острова подстраивается под название
        val textW = miniTitle.paint.measureText(miniText)
        miniW = if (idle) {
            (dp(36f) + textW).coerceIn(dp(130f), dp(260f))
        } else {
            (dp(8f + 22f + 8f + 8f + 14f + 27f) + textW).coerceIn(dp(150f), dp(300f))
        }
        if (!expanded) go(miniW, miniH, miniH / 2)
        requestLayout()

        // анимация смены трека в сторону переключения
        if (t.title.isNotEmpty() && lastTitle.isNotEmpty() && t.title != lastTitle) {
            val dir = if (System.currentTimeMillis() - skipAt < 4000) skipDir else 1
            slideIn(miniTitle, dir)
            slideIn(fullTitle, dir)
            slideIn(fullArtist, dir)
            pop(miniCover); pop(fullCover)
        }
        lastTitle = t.title
    }

    private fun setBlurBackground(c: Bitmap?) {
        if (c == null) {
            bgImage.animate().alpha(0f).setDuration(400).start()
            return
        }
        try {
            val soft = if (c.config == Bitmap.Config.HARDWARE) c.copy(Bitmap.Config.ARGB_8888, false) else c
            // крошечная копия обложки, растянутая обратно, даёт мягкое размытие без нагрузки
            val tiny = Bitmap.createScaledBitmap(soft, 12, 12, true)
            bgImage.setImageBitmap(tiny)
            bgImage.setColorFilter(Color.argb(150, 0, 0, 0), PorterDuff.Mode.SRC_ATOP)
            bgImage.animate().cancel()
            bgImage.alpha = 0f
            bgImage.animate().alpha(1f).setDuration(700).start()
        } catch (e: Exception) {
            bgImage.alpha = 0f
        }
    }

    private fun slideIn(v: View, dir: Int) {
        v.animate().cancel()
        v.translationX = dir * dp(34f)
        v.alpha = 0f
        v.animate().translationX(0f).alpha(1f).setDuration(480)
            .setInterpolator(OvershootInterpolator(2f)).start()
    }

    private fun pop(v: View) {
        v.animate().cancel()
        v.scaleX = 0.6f
        v.scaleY = 0.6f
        v.animate().scaleX(1f).scaleY(1f).setDuration(520)
            .setInterpolator(OvershootInterpolator(3f)).start()
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private fun updateProgress() {
        val dur = tracker.durationMs
        if (expanded && dur > 0) {
            val p = tracker.positionMs()
            if (!seek.dragging) seek.progress = (p.toFloat() / dur).coerceIn(0f, 1f)
            timeL.text = fmt(if (seek.dragging) (seek.progress * dur).toLong() else p)
            timeR.text = fmt(dur)
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            if (idleMode && !expanded) {
                val t = clock()
                if (miniTitle.text.toString() != t) refresh()
            }
            handler.postDelayed(this, 250)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        refresh() // первый показ (часы), до подключения к музыке
        tracker.start()
        handler.post(ticker)
    }

    override fun onDetachedFromWindow() {
        release()
        super.onDetachedFromWindow()
    }

    fun release() {
        tracker.stop()
        handler.removeCallbacksAndMessages(null)
        Choreographer.getInstance().removeFrameCallback(frame)
        looping = false
    }
}

// ============================================================
//  Иконки кнопок, нарисованные вручную
// ============================================================
class IconView(ctx: Context, var kind: Int) : View(ctx) {

    companion object {
        const val PREV = 0
        const val PLAY = 1
        const val PAUSE = 2
        const val NEXT = 3
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val path = Path()

    init {
        isClickable = true
        // кнопка вдавливается и пружинит обратно
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.78f).scaleY(0.78f).setDuration(70).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(380)
                        .setInterpolator(OvershootInterpolator(4f)).start()
            }
            false
        }
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val u = min(width, height) * 0.27f
        path.reset()
        when (kind) {
            PLAY -> {
                path.moveTo(cx - u * 0.7f, cy - u)
                path.lineTo(cx + u, cy)
                path.lineTo(cx - u * 0.7f, cy + u)
                path.close()
            }
            PAUSE -> {
                path.addRect(cx - u * 0.9f, cy - u, cx - u * 0.25f, cy + u, Path.Direction.CW)
                path.addRect(cx + u * 0.25f, cy - u, cx + u * 0.9f, cy + u, Path.Direction.CW)
            }
            NEXT -> {
                path.moveTo(cx - u, cy - u * 0.9f)
                path.lineTo(cx + u * 0.5f, cy)
                path.lineTo(cx - u, cy + u * 0.9f)
                path.close()
                path.addRect(cx + u * 0.6f, cy - u * 0.9f, cx + u, cy + u * 0.9f, Path.Direction.CW)
            }
            else -> {
                path.moveTo(cx + u, cy - u * 0.9f)
                path.lineTo(cx - u * 0.5f, cy)
                path.lineTo(cx + u, cy + u * 0.9f)
                path.close()
                path.addRect(cx - u, cy - u * 0.9f, cx - u * 0.6f, cy + u * 0.9f, Path.Direction.CW)
            }
        }
        c.drawPath(path, paint)
    }
}

// ============================================================
//  Ползунок перемотки
// ============================================================
class SeekView(ctx: Context) : View(ctx) {

    var progress = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var dragging = false
        private set
    var onSeek: ((Float) -> Unit)? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val cy = height / 2f
        val th = 4 * d
        p.color = 0x40FFFFFF
        c.drawRoundRect(0f, cy - th / 2, width.toFloat(), cy + th / 2, th / 2, th / 2, p)
        p.color = Color.WHITE
        val x = width * progress
        c.drawRoundRect(0f, cy - th / 2, max(x, th), cy + th / 2, th / 2, th / 2, p)
        val r = if (dragging) 8 * d else 5 * d
        c.drawCircle(x.coerceIn(r, width - r), cy, r, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                setFrom(e.x)
            }
            MotionEvent.ACTION_MOVE -> setFrom(e.x)
            MotionEvent.ACTION_UP -> {
                setFrom(e.x)
                dragging = false
                onSeek?.invoke(progress)
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                invalidate()
            }
        }
        return true
    }

    private fun setFrom(x: Float) {
        if (width > 0) progress = x / width
    }
}

// ============================================================
//  Анимация «эквалайзера»: полоски прыгают, пока играет музыка
//  (это именно анимация, а не реальный отклик на звук)
// ============================================================
class EqView(ctx: Context) : View(ctx) {

    var playing = false
        set(v) {
            field = v
            invalidate()
        }

    private val cur = FloatArray(5) { 0.12f }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeCap = Paint.Cap.ROUND
    }

    override fun onDraw(c: Canvas) {
        val t = System.nanoTime() / 1e9
        val n = 5
        val d = resources.displayMetrics.density
        val w = 3 * d
        p.strokeWidth = w
        val gap = (width - n * w) / (n - 1)
        var moving = false
        for (i in 0 until n) {
            val target = if (playing) (0.25 + 0.75 * abs(sin(t * (2.1 + i * 0.7) + i * 1.3))).toFloat() else 0.12f
            cur[i] += (target - cur[i]) * 0.25f
            if (playing || abs(target - cur[i]) > 0.01f) moving = true
            val h = max(w, cur[i] * height)
            val x = w / 2 + i * (w + gap)
            c.drawLine(x, height / 2f - h / 2 + w / 2, x, height / 2f + h / 2 - w / 2, p)
        }
        if (moving) postInvalidateOnAnimation()
    }
}

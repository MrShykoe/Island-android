package com.mrsh1zuky.island

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ============================================================
//  Сам остров: чёрная пилюля вокруг камеры, раскрывается пружиной.
//  Свёрнутый вид: обложка слева от камеры, текст делится пополам и обтекает камеру, эквалайзер справа.
// ============================================================
class IslandView(ctx: Context) : FrameLayout(ctx), Media.Listener {

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density
    private fun dpi(v: Int) = (v * density).toInt()

    private enum class M { MINI, FULL, NOTIF }

    private companion object {
        // обложка 56 + 14 + ползунок со временем 32 + 6 + кнопки 48
        const val FULL_CONTENT_DP = 156f
    }

    // ---------- пружина ----------
    private class Spring(var p: Double) {
        var v = 0.0
        var t = p
        fun step(dt: Double) {
            val a = -170.0 * (p - t) - 13.0 * v // меньше второе число = больше «желе»
            v += a * dt
            p += v * dt
        }
        fun settled() = abs(p - t) < 0.4 && abs(v) < 0.4
    }

    // ---------- геометрия с учётом камеры ----------
    private val cut = Cutout.read(ctx)
    private val screenW: Float get() = resources.displayMetrics.widthPixels.toFloat()
    private fun pref(key: String) = dp(Prefs.getInt(context, key).toFloat())

    private val miniH = pref(Prefs.MINI_H)
    val topY: Int = max(0f, cut.centerY - miniH / 2f + pref(Prefs.OFFSET_Y)).toInt()
    private val topClear = max(dp(22f), cut.bottom - topY + pref(Prefs.UNDER_CAM)) // место под камерой
    private val gap = cut.gap
    private val pad = pref(Prefs.FULL_PAD)

    // Свёрнутый остров никогда не шире настройки и не шире экрана: раньше он мог вылезать за края
    private val miniMaxW: Float get() = min(pref(Prefs.MINI_W), screenW - dp(24f))
    private val sideCap: Float get() = max(dp(30f), (miniMaxW - dp(84f) - gap) / 2f)
    private var miniW = min(dp(190f), miniMaxW)
    private var notifW = dp(300f)
    private val notifH = topClear + dp(40f) + dp(14f)
    private val fullH = topClear + dp(FULL_CONTENT_DP) + pad
    private val fullW: Float get() = min(pref(Prefs.FULL_W), screenW - dp(24f))

    private val sw = Spring(miniW.toDouble())
    private val sh = Spring(miniH.toDouble())
    private val sr = Spring((miniH / 2).toDouble())
    private val bg = GradientDrawable().apply {
        setColor(Color.BLACK)
        cornerRadius = miniH / 2
    }

    // ---------- состояние ----------
    private var mode = M.MINI
    private var expanded = false
    private var expandedAt = 0L
    private var lastTitle = ""
    private var skipDir = 1
    private var skipAt = 0L
    private var idle = true
    private val handler = Handler(Looper.getMainLooper())

    // слова песни в свёрнутом виде
    private var lyrIdx = -2
    private var ww: WordWave? = null
    private var wl = 0f
    private var wr = 0f

    // ---------- свёрнутый вид ----------
    private val backdrop = CoverBackdrop(ctx, blurDp = 10f, dim = 0x73000000)
    private val miniCover = makeCover(11f)
    private val leftText = WaveText(ctx).apply {
        align = 1
        gravity = Gravity.END or Gravity.CENTER_VERTICAL
        ellipsize = TextUtils.TruncateAt.START
        setPadding(dpi(8), 0, dpi(2), 0)
    }
    private val gapView = View(ctx)
    private val rightText = WaveText(ctx).apply {
        align = 0
        gravity = Gravity.START or Gravity.CENTER_VERTICAL
        ellipsize = TextUtils.TruncateAt.END
        setPadding(dpi(2), 0, dpi(8), 0)
    }
    private val miniEq = EqView(ctx)
    private val mini = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dpi(10), 0, dpi(10), 0)
    }

    // ---------- развёрнутый вид ----------
    private val fullCover = makeCover(14f)
    private val fullTitle = TextView(ctx).apply {
        setTextColor(Color.WHITE)
        textSize = 16f
        setTypeface(typeface, Typeface.BOLD)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }
    private val fullArtist = TextView(ctx).apply {
        setTextColor(0xFF999999.toInt())
        textSize = 13f
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }
    private val fullEq = EqView(ctx)
    private val timeL = TextView(ctx).apply {
        setTextColor(0xFF9A9A9A.toInt()); textSize = 11f; text = "0:00"; gravity = Gravity.START
    }
    private val timeR = TextView(ctx).apply {
        setTextColor(0xFF9A9A9A.toInt()); textSize = 11f; text = "0:00"; gravity = Gravity.END
    }
    private val seek = SeekView(ctx)
    private val prev = IconView(ctx, IconView.PREV)
    private val play = IconView(ctx, IconView.PLAY)
    private val next = IconView(ctx, IconView.NEXT)
    private val expandBtn = IconView(ctx, IconView.EXPAND)
    private val full = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(pad.toInt(), topClear.toInt(), pad.toInt(), pad.toInt())
    }

    // ---------- уведомление ----------
    private val notifIcon = makeCover(12f)
    private val notifTitle = TextView(ctx).apply {
        setTextColor(Color.WHITE); textSize = 14f
        setTypeface(typeface, Typeface.BOLD)
        maxLines = 1; ellipsize = TextUtils.TruncateAt.END
    }
    private val notifBody = TextView(ctx).apply {
        setTextColor(0xFFAAAAAA.toInt()); textSize = 13f
        maxLines = 1; ellipsize = TextUtils.TruncateAt.END
    }
    private val notif = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dpi(16), topClear.toInt(), dpi(16), dpi(14))
    }

    init {
        background = bg
        clipToOutline = true
        outlineProvider = ViewOutlineProvider.BACKGROUND

        // свёрнутый: обложка | текст слева | камера | текст справа | эквалайзер (по бокам одинаково, камера по центру)
        mini.addView(miniCover, LinearLayout.LayoutParams(dpi(22), dpi(22)))
        mini.addView(leftText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        mini.addView(gapView, LinearLayout.LayoutParams(gap.toInt(), 1))
        mini.addView(rightText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        mini.addView(miniEq, LinearLayout.LayoutParams(dpi(22), dpi(18)))
        for (t in listOf(leftText, rightText)) {
            t.setTextColor(Color.WHITE); t.textSize = Prefs.getInt(ctx, Prefs.MINI_TEXT).toFloat(); t.maxLines = 1
        }

        // развёрнутый
        val textCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            addView(fullTitle)
            addView(fullArtist)
        }
        // Всё в раскрытом виде считается от одной сетки: 56 | 14 | 32 | 6 | 48 (см. FULL_CONTENT_DP), отступы слева/справа равны
        val top = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(fullCover, LinearLayout.LayoutParams(dpi(56), dpi(56)))
            addView(textCol, LinearLayout.LayoutParams(0, dpi(56), 1f).apply { setMargins(dpi(12), 0, dpi(8), 0) })
            addView(fullEq, LinearLayout.LayoutParams(dpi(20), dpi(16)))
            addView(expandBtn, LinearLayout.LayoutParams(dpi(36), dpi(36)).apply { setMargins(dpi(6), 0, 0, 0) })
        }
        val timesRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(timeL, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            addView(timeR, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
        val seekBlock = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(seek, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpi(18)))
            addView(timesRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpi(14)))
        }
        val controls = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            for (b in listOf(prev, play, next)) {
                addView(b, LinearLayout.LayoutParams(dpi(64), dpi(48)).apply { setMargins(dpi(8), 0, dpi(8), 0) })
            }
        }
        full.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpi(56)))
        full.addView(seekBlock, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpi(32)).apply {
            topMargin = dpi(14)
        })
        full.addView(controls, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpi(48)).apply {
            topMargin = dpi(6)
        })

        // уведомление
        val nCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(notifTitle)
            addView(notifBody)
        }
        notif.addView(notifIcon, LinearLayout.LayoutParams(dpi(40), dpi(40)))
        notif.addView(nCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dpi(12), 0, 0, 0)
        })

        addView(backdrop)
        addView(mini)
        addView(full)
        addView(notif)
        full.alpha = 0f; full.visibility = INVISIBLE
        notif.alpha = 0f; notif.visibility = INVISIBLE

        // действия
        prev.setOnClickListener {
            skipDir = -1; skipAt = System.currentTimeMillis()
            Media.controller?.transportControls?.skipToPrevious()
        }
        next.setOnClickListener {
            skipDir = 1; skipAt = System.currentTimeMillis()
            Media.controller?.transportControls?.skipToNext()
        }
        play.setOnClickListener {
            Media.controller?.let {
                if (Media.playing) it.transportControls.pause() else it.transportControls.play()
            }
        }
        seek.onSeek = { r ->
            if (Media.durationMs > 0) {
                Media.controller?.transportControls?.seekTo((r * Media.durationMs).toLong())
            }
        }
        expandBtn.setOnClickListener { openPlayer() }
        fullCover.setOnClickListener { openPlayer() }
        notif.setOnClickListener { hideNotif() }
        setOnClickListener {
            if (mode == M.MINI) {
                expanded = true
                expandedAt = SystemClock.elapsedRealtime()
                applyMode(M.FULL)
            }
        }
    }

    private fun makeCover(radiusDp: Float): ImageView {
        val r = radiusDp * density
        return ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF333333.toInt())
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, r)
                }
            }
        }
    }

    private fun openPlayer() {
        try {
            context.startActivity(Intent(context, PlayerActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
        }
        expanded = false
        applyMode(M.MINI)
    }

    // ============================================================
    //  Анимация размера (пружина)
    // ============================================================
    private var looping = false
    private var lastNs = 0L
    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            val dt = min(0.032, (frameTimeNanos - lastNs) / 1e9)
            lastNs = frameTimeNanos
            sw.step(dt); sh.step(dt); sr.step(dt)
            applySize()
            if (sw.settled() && sh.settled() && sr.settled()) {
                sw.p = sw.t; sh.p = sh.t; sr.p = sr.t
                applySize()
                looping = false
            } else {
                Choreographer.getInstance().postFrameCallback(this)
            }
        }
    }

    private fun go(w: Float, h: Float, r: Float) {
        sw.t = w.toDouble(); sh.t = h.toDouble(); sr.t = r.toDouble()
        if (!looping) {
            looping = true
            lastNs = System.nanoTime()
            Choreographer.getInstance().postFrameCallback(frame)
        }
    }

    private fun applySize() {
        val h = max(1.0, sh.p)
        bg.cornerRadius = sr.p.toFloat().coerceIn(0f, (h / 2).toFloat())
        invalidateOutline()
        requestLayout()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = max(1, sw.p.toInt())
        val h = max(1, sh.p.toInt())
        setMeasuredDimension(w, h)
        backdrop.measure(exact(w), exact(h))
        // содержимое всегда выкладывается на итоговую ширину: текст не дёргается, пока остров растёт
        mini.measure(exact(miniW.toInt()), exact(miniH.toInt()))
        full.measure(exact(fullW.toInt()), exact(fullH.toInt()))
        notif.measure(exact(notifW.toInt()), exact(notifH.toInt()))
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        backdrop.layout(0, 0, w, h)
        centerTop(mini, w, miniH.toInt())
        centerIn(full, w, h)
        centerIn(notif, w, h)
    }

    private fun centerIn(v: View, w: Int, h: Int) {
        val x = (w - v.measuredWidth) / 2
        val y = (h - v.measuredHeight) / 2
        v.layout(x, y, x + v.measuredWidth, y + v.measuredHeight)
    }

    // свёрнутое содержимое всегда у самого верха, там же, где камера
    private fun centerTop(v: View, w: Int, h: Int) {
        val x = (w - v.measuredWidth) / 2
        v.layout(x, 0, x + v.measuredWidth, h)
    }

    private fun exact(px: Int) = MeasureSpec.makeMeasureSpec(px, MeasureSpec.EXACTLY)

    private fun fade(v: View, show: Boolean) {
        v.animate().cancel()
        if (show) {
            v.visibility = VISIBLE
            v.animate().alpha(1f).setDuration(260).start()
        } else {
            v.animate().alpha(0f).setDuration(120).withEndAction { v.visibility = INVISIBLE }.start()
        }
    }

    private fun applyMode(m: M) {
        mode = m
        when (m) {
            M.MINI -> go(miniW, miniH, miniH / 2)
            M.FULL -> go(fullW, fullH, dp(34f))
            M.NOTIF -> go(notifW, notifH, dp(30f))
        }
        fade(mini, m == M.MINI)
        fade(full, m == M.FULL)
        fade(notif, m == M.NOTIF)
        updateProgress()
    }

    private fun restMode() = if (expanded) M.FULL else M.MINI

    // тап за пределами острова сворачивает его
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_OUTSIDE && expanded &&
            SystemClock.elapsedRealtime() - expandedAt > 600
        ) {
            expanded = false
            if (mode == M.FULL) applyMode(M.MINI)
        }
        return super.dispatchTouchEvent(ev)
    }

    // ============================================================
    //  Текст у камеры
    // ============================================================
    private fun measure(s: String) = leftText.paint.measureText(s)

    // Текст делится по словам так, чтобы половины были примерно равны: он обтекает камеру
    private fun splitText(s: String): Pair<String, String> {
        val words = s.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.size <= 1) return Pair(s.trim(), "")
        var best = 1
        var bestDiff = Float.MAX_VALUE
        for (i in 1 until words.size) {
            val d = abs(measure(words.subList(0, i).joinToString(" ")) - measure(words.subList(i, words.size).joinToString(" ")))
            if (d < bestDiff) {
                bestDiff = d
                best = i
            }
        }
        return Pair(words.subList(0, best).joinToString(" "), words.subList(best, words.size).joinToString(" "))
    }

    private fun applyMiniTextSize(sp: Float) {
        leftText.textSize = sp
        rightText.textSize = sp
    }

    private fun setMiniParts(l: String, r: String) {
        // если текст не помещается по бокам камеры, чуть уменьшаем шрифт (но не меньше 9sp), а не раздуваем остров за экран
        var size = Prefs.getInt(context, Prefs.MINI_TEXT).toFloat()
        applyMiniTextSize(size)
        var a = measure(l)
        var b = measure(r)
        val cap = sideCap
        while (max(a, b) > cap && size > 9f) {
            size -= 0.5f
            applyMiniTextSize(size)
            a = measure(l)
            b = measure(r)
        }
        leftText.text = l
        rightText.text = r
        wl = a
        wr = b
        leftText.textW = a
        rightText.textW = b
        val side = min(cap, max(dp(34f), max(a, b)))
        // по бокам камеры всё одинаково: 20 (отступы) + 22 (обложка или эквалайзер) + 10 (поля текста)
        miniW = dp(2 * (10f + 22f + 10f)) + gap + 2 * side
        if (mode == M.MINI) go(miniW, miniH, miniH / 2)
        requestLayout()
    }

    private fun setMiniText(s: String) {
        val (l, r) = splitText(s)
        setMiniParts(l, r)
    }

    private fun clock() = SimpleDateFormat("HH:mm", Locale("ru")).format(Date())
    private fun date() = SimpleDateFormat("EEE, d MMM", Locale("ru")).format(Date())

    private fun lyricsActive() = Prefs.get(context, Prefs.LYRICS) && !idle && Media.lyrics != null

    private fun refreshMiniText() {
        leftText.wave = -1f; rightText.wave = -1f
        when {
            !Media.hasAccess -> setMiniText("Нужен доступ к уведомлениям")
            idle -> setMiniParts(clock(), date())
            lyricsActive() -> {
                lyrIdx = -2
                lyricTick()
            }
            else -> setMiniText(Media.title.ifEmpty { "Играет" })
        }
    }

    // ============================================================
    //  Слова песни: волна света бежит по строке слева направо, огибая камеру
    // ============================================================
    private fun lyricTick() {
        if (mode != M.MINI || !lyricsActive()) return
        val lines = Media.lyrics ?: return
        val t = Media.positionMs() / 1000.0 + 0.15
        var idx = -1
        for (i in lines.indices) {
            if (lines[i].t <= t) idx = i else break
        }
        if (idx != lyrIdx) {
            lyrIdx = idx
            setLine(lines, idx)
        }
        val w = ww
        if (w != null && Prefs.get(context, Prefs.WAVE)) {
            val x = w.xAt(t)
            leftText.wave = x.coerceIn(0f, wl)
            rightText.wave = (x - wl - leftText.paint.measureText(" ")).coerceIn(0f, wr)
            leftText.invalidate(); rightText.invalidate()
        }
    }

    private fun setLine(lines: List<Media.Line>, idx: Int) {
        ww = null
        leftText.wave = -1f; rightText.wave = -1f
        val line = if (idx >= 0) lines[idx].s else ""
        if (line.isBlank()) {
            setMiniText(Media.title.ifEmpty { "Играет" })
        } else {
            setMiniText(line)
            if (Prefs.get(context, Prefs.WAVE)) {
                ww = WordWave(lines[idx], leftText.paint)
                leftText.wave = 0f; rightText.wave = 0f
            }
        }
        for (v in listOf(leftText, rightText)) {
            v.animate().cancel()
            v.translationY = dp(9f)
            v.animate().translationY(0f).setDuration(380).setInterpolator(OvershootInterpolator(1.6f)).start()
        }
    }

    // ============================================================
    //  Данные о музыке
    // ============================================================
    override fun onMedia() {
        idle = Media.hasAccess && Media.controller == null
        miniCover.visibility = if (idle) INVISIBLE else VISIBLE
        miniEq.visibility = if (idle) INVISIBLE else VISIBLE

        fullTitle.text = if (idle) "Ничего не играет" else Media.title.ifEmpty { "Играет" }
        fullArtist.text = if (idle) "" else Media.artist

        val c = Media.cover
        miniCover.setImageBitmap(c)
        fullCover.setImageBitmap(c)
        backdrop.set(c, Prefs.get(context, Prefs.BLUR))

        miniEq.playing = Media.playing
        fullEq.playing = Media.playing
        val newKind = if (Media.playing) IconView.PAUSE else IconView.PLAY
        if (play.kind != newKind) {
            play.kind = newKind
            play.invalidate()
            pop(play)
        }

        if (!lyricsActive()) refreshMiniText()

        // смена трека: название и обложка влетают с той стороны, куда переключили
        val title = Media.title
        if (title.isNotEmpty() && lastTitle.isNotEmpty() && title != lastTitle) {
            val dir = if (System.currentTimeMillis() - skipAt < 4000) skipDir else 1
            slideIn(fullTitle, dir)
            slideIn(fullArtist, dir)
            slideIn(leftText, dir)
            slideIn(rightText, dir)
            pop(miniCover); pop(fullCover)
        }
        lastTitle = title
    }

    override fun onLyrics() {
        refreshMiniText()
    }

    private fun slideIn(v: View, dir: Int) {
        v.animate().cancel()
        v.translationX = dir * dp(34f)
        v.alpha = 0f
        v.animate().translationX(0f).alpha(1f).setDuration(480)
            .setInterpolator(OvershootInterpolator(2f)).start()
    }

    private fun pop(v: View) {
        v.animate().cancel()
        v.scaleX = 0.6f
        v.scaleY = 0.6f
        v.animate().scaleX(1f).scaleY(1f).setDuration(520)
            .setInterpolator(OvershootInterpolator(3f)).start()
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private fun updateProgress() {
        val dur = Media.durationMs
        if (mode == M.FULL && dur > 0) {
            val p = Media.positionMs()
            if (!seek.dragging) seek.progress = (p.toFloat() / dur).coerceIn(0f, 1f)
            timeL.text = fmt(if (seek.dragging) (seek.progress * dur).toLong() else p)
            timeR.text = fmt(dur)
        }
    }

    // ============================================================
    //  Уведомления
    // ============================================================
    private val hideNotifRun = Runnable { hideNotif() }

    private fun showNotif(it: Notifs.Item) {
        if (!Prefs.get(context, Prefs.NOTIFS)) return
        notifIcon.setImageDrawable(it.icon)
        notifTitle.text = it.title.ifEmpty { it.app }
        notifBody.text = if (it.title.isEmpty()) "" else it.text.ifEmpty { it.app }
        if (it.title.isEmpty()) notifBody.text = it.text
        val tw = max(notifTitle.paint.measureText(notifTitle.text.toString()), notifBody.paint.measureText(notifBody.text.toString()))
        val hi = max(dp(240f), min(fullW, screenW - dp(24f)))
        notifW = (dp(16f + 40f + 12f + 16f) + tw).coerceIn(dp(240f), hi)
        applyMode(M.NOTIF)
        slideIn(notifIcon, -1)
        pop(notifIcon)
        handler.removeCallbacks(hideNotifRun)
        handler.postDelayed(hideNotifRun, 4500)
    }

    private fun hideNotif() {
        handler.removeCallbacks(hideNotifRun)
        if (mode == M.NOTIF) applyMode(restMode())
    }

    // ============================================================
    //  Циклы
    // ============================================================
    private var tick = 0
    private val ticker = object : Runnable {
        override fun run() {
            lyricTick()
            tick++
            if (tick % 6 == 0) updateProgress()
            if (tick % 25 == 0 && idle && mode == M.MINI) {
                val l = clock()
                if (leftText.text.toString() != l) refreshMiniText()
            }
            handler.postDelayed(this, 40)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        Media.attach(context, this)
        Notifs.listener = { showNotif(it) }
        handler.post(ticker)
    }

    override fun onDetachedFromWindow() {
        release()
        super.onDetachedFromWindow()
    }

    fun release() {
        Media.detach(this)
        Notifs.listener = null
        handler.removeCallbacksAndMessages(null)
        Choreographer.getInstance().removeFrameCallback(frame)
        looping = false
    }
}

// ============================================================
//  Текст с бегущей «волной света» слева направо
//  (поверх обычного текста накладывается градиент: уже спетое ярко, остальное тускло)
// ============================================================
class WaveText(ctx: Context) : TextView(ctx) {
    var wave = -1f   // сколько пикселей текста уже «загорелось»; меньше нуля = эффект выключен
    var textW = 0f
    var align = 0    // 0 текст прижат влево, 1 вправо, 2 по центру

    private val dim = 0x40FFFFFF

    override fun onDraw(canvas: Canvas) {
        if (wave >= 0f && textW > 1f && text.isNotEmpty()) {
            val f = 12f * resources.displayMetrics.density // мягкость края волны
            val len = textW + 8f
            val avail = width - paddingLeft - paddingRight
            val off = when (align) {
                1 -> width - paddingRight - textW
                2 -> paddingLeft + (avail - textW) / 2f
                else -> paddingLeft.toFloat()
            }
            val cx = -f + wave / textW * (textW + 2 * f)
            val a = ((cx - f) / len).coerceIn(0f, 1f)
            val b = ((cx + f) / len).coerceIn(0f, 1f)
            paint.shader = LinearGradient(
                off, 0f, off + len, 0f,
                intArrayOf(Color.WHITE, Color.WHITE, dim, dim),
                floatArrayOf(0f, a, b, 1f), Shader.TileMode.CLAMP
            )
            super.onDraw(canvas)
            paint.shader = null
        } else {
            super.onDraw(canvas)
        }
    }
}

// Позиция «волны» внутри строки по таймингу слов (см. Timing): считается по символам, поэтому заливка идёт слово за словом
class WordWave(line: Media.Line, private val paint: Paint) {
    private val text = line.s
    private val words = line.timing
    val width: Float = paint.measureText(text)

    fun xAt(t: Double): Float {
        if (text.isEmpty()) return 0f
        val cp = Timing.charPos(words, t, text.length)
        val i = cp.toInt().coerceIn(0, text.length)
        val x0 = if (i == 0) 0f else paint.measureText(text, 0, i)
        if (i >= text.length) return x0
        val x1 = paint.measureText(text, 0, i + 1)
        return x0 + (cp - i) * (x1 - x0)
    }
}

// ============================================================
//  Иконки кнопок, нарисованные вручную
// ============================================================
class IconView(ctx: Context, var kind: Int) : View(ctx) {

    companion object {
        const val PREV = 0
        const val PLAY = 1
        const val PAUSE = 2
        const val NEXT = 3
        const val EXPAND = 4
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()

    init {
        isClickable = true
        // кнопка вдавливается и пружинит обратно
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.78f).scaleY(0.78f).setDuration(70).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(380)
                        .setInterpolator(OvershootInterpolator(4f)).start()
            }
            false
        }
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val u = min(width, height) * 0.27f
        path.reset()
        when (kind) {
            PLAY -> {
                path.moveTo(cx - u * 0.7f, cy - u)
                path.lineTo(cx + u, cy)
                path.lineTo(cx - u * 0.7f, cy + u)
                path.close()
            }
            PAUSE -> {
                path.addRect(cx - u * 0.9f, cy - u, cx - u * 0.25f, cy + u, Path.Direction.CW)
                path.addRect(cx + u * 0.25f, cy - u, cx + u * 0.9f, cy + u, Path.Direction.CW)
            }
            NEXT -> {
                path.moveTo(cx - u, cy - u * 0.9f)
                path.lineTo(cx + u * 0.5f, cy)
                path.lineTo(cx - u, cy + u * 0.9f)
                path.close()
                path.addRect(cx + u * 0.6f, cy - u * 0.9f, cx + u, cy + u * 0.9f, Path.Direction.CW)
            }
            PREV -> {
                path.moveTo(cx + u, cy - u * 0.9f)
                path.lineTo(cx - u * 0.5f, cy)
                path.lineTo(cx + u, cy + u * 0.9f)
                path.close()
                path.addRect(cx - u, cy - u * 0.9f, cx - u * 0.6f, cy + u * 0.9f, Path.Direction.CW)
            }
            else -> {
                // значок «на весь экран»: четыре уголка
                stroke.strokeWidth = resources.displayMetrics.density * 2f
                val k = u * 0.45f
                path.moveTo(cx - u, cy - k); path.lineTo(cx - u, cy - u); path.lineTo(cx - k, cy - u)
                path.moveTo(cx + k, cy - u); path.lineTo(cx + u, cy - u); path.lineTo(cx + u, cy - k)
                path.moveTo(cx + u, cy + k); path.lineTo(cx + u, cy + u); path.lineTo(cx + k, cy + u)
                path.moveTo(cx - k, cy + u); path.lineTo(cx - u, cy + u); path.lineTo(cx - u, cy + k)
                c.drawPath(path, stroke)
                return
            }
        }
        c.drawPath(path, paint)
    }
}

// ============================================================
//  Ползунок перемотки
// ============================================================
class SeekView(ctx: Context) : View(ctx) {

    var progress = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var dragging = false
        private set
    var onSeek: ((Float) -> Unit)? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val cy = height / 2f
        val th = 4 * d
        p.color = 0x40FFFFFF
        c.drawRoundRect(0f, cy - th / 2, width.toFloat(), cy + th / 2, th / 2, th / 2, p)
        p.color = Color.WHITE
        val x = width * progress
        c.drawRoundRect(0f, cy - th / 2, max(x, th), cy + th / 2, th / 2, th / 2, p)
        val r = if (dragging) 8 * d else 5 * d
        c.drawCircle(x.coerceIn(r, width - r), cy, r, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                setFrom(e.x)
            }
            MotionEvent.ACTION_MOVE -> setFrom(e.x)
            MotionEvent.ACTION_UP -> {
                setFrom(e.x)
                dragging = false
                onSeek?.invoke(progress)
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                invalidate()
            }
        }
        return true
    }

    private fun setFrom(x: Float) {
        if (width > 0) progress = x / width
    }
}

// ============================================================
//  Анимация «эквалайзера»: полоски прыгают, пока играет музыка
//  (это именно анимация, а не реальный отклик на звук)
// ============================================================
class EqView(ctx: Context) : View(ctx) {

    var playing = false
        set(v) {
            field = v
            invalidate()
        }

    private val cur = FloatArray(5) { 0.12f }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeCap = Paint.Cap.ROUND
    }

    override fun onDraw(c: Canvas) {
        val t = System.nanoTime() / 1e9
        val n = 5
        val d = resources.displayMetrics.density
        val w = 3 * d
        p.strokeWidth = w
        val gap = (width - n * w) / (n - 1)
        var moving = false
        for (i in 0 until n) {
            val target = if (playing) (0.25 + 0.75 * abs(sin(t * (2.1 + i * 0.7) + i * 1.3))).toFloat() else 0.12f
            cur[i] += (target - cur[i]) * 0.25f
            if (playing || abs(target - cur[i]) > 0.01f) moving = true
            val h = max(w, cur[i] * height)
            val x = w / 2 + i * (w + gap)
            c.drawLine(x, height / 2f - h / 2 + w / 2, x, height / 2f + h / 2 - w / 2, p)
        }
        if (moving) postInvalidateOnAnimation()
    }
}

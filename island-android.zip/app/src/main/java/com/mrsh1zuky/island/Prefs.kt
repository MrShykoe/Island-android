package com.mrsh1zuky.island

import android.content.Context

object Prefs {
    // переключатели (по умолчанию включены)
    const val LYRICS = "lyrics"
    const val WAVE = "wave"
    const val EXTRA = "extra"
    const val BLUR = "blur"
    const val NOTIFS = "notifs"
    const val LYR_BLUR = "lyr_blur"
    const val ENABLED = "island_on"

    // числовые настройки (ползунки)
    const val MINI_W = "mini_w"
    const val MINI_H = "mini_h"
    const val OFFSET_Y = "offset_y"
    const val MINI_TEXT = "mini_text"
    const val FULL_W = "full_w"
    const val FULL_PAD = "full_pad"
    const val UNDER_CAM = "under_cam"
    const val LYR_SIZE = "lyr_size"

    class Slider(
        val key: String,
        val label: String,
        val def: Int,
        val min: Int,
        val max: Int,
        val unit: String,
        val affectsIsland: Boolean = true
    )

    val SLIDERS = listOf(
        Slider(MINI_W, "Макс. ширина свёрнутого острова", 280, 190, 360, "dp"),
        Slider(MINI_H, "Высота свёрнутого острова", 36, 26, 48, "dp"),
        Slider(OFFSET_Y, "Сдвиг острова по вертикали", 0, -10, 20, "dp"),
        Slider(MINI_TEXT, "Размер текста в свёрнутом острове", 12, 9, 15, "sp"),
        Slider(FULL_W, "Ширина раскрытого острова", 340, 260, 400, "dp"),
        Slider(FULL_PAD, "Внутренние отступы раскрытого острова", 20, 12, 32, "dp"),
        Slider(UNDER_CAM, "Отступ контента под камерой", 8, 0, 24, "dp"),
        Slider(LYR_SIZE, "Размер слов в плеере", 28, 18, 40, "sp", affectsIsland = false)
    )

    private fun sp(c: Context) = c.getSharedPreferences("island", Context.MODE_PRIVATE)

    fun get(c: Context, key: String): Boolean = sp(c).getBoolean(key, true)
    fun set(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean(key, v).apply()

    fun getInt(c: Context, key: String): Int {
        val s = SLIDERS.first { it.key == key }
        return sp(c).getInt(key, s.def).coerceIn(s.min, s.max)
    }

    fun setInt(c: Context, key: String, v: Int) = sp(c).edit().putInt(key, v).apply()

    fun resetSliders(c: Context) {
        val e = sp(c).edit()
        for (s in SLIDERS) e.remove(s.key)
        e.apply()
    }
}

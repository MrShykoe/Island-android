package com.mrsh1zuky.island

import android.content.Context

object Prefs {
    const val LYRICS = "lyrics"
    const val WAVE = "wave"
    const val EXTRA = "extra"
    const val BLUR = "blur"
    const val NOTIFS = "notifs"

    private fun sp(c: Context) = c.getSharedPreferences("island", Context.MODE_PRIVATE)
    fun get(c: Context, key: String): Boolean = sp(c).getBoolean(key, true)
    fun set(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean(key, v).apply()
}

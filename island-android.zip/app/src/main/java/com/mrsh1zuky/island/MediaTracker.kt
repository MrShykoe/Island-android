package com.mrsh1zuky.island

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock

// Следит за текущей музыкой в системе (Spotify, YouTube Music, браузер и т.д.).
// Для этого Android требует, чтобы был выдан доступ к уведомлениям.
class MediaTracker(private val ctx: Context, private val onChange: () -> Unit) {

    var controller: MediaController? = null
        private set
    var title = ""
        private set
    var artist = ""
        private set
    var cover: Bitmap? = null
        private set
    var durationMs = 0L
        private set
    var playing = false
        private set
    var hasAccess = true
        private set

    private val msm = ctx.getSystemService(MediaSessionManager::class.java)
    private val listenerName = ComponentName(ctx, MediaListener::class.java)

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list ?: emptyList()) }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = read()
        override fun onPlaybackStateChanged(state: PlaybackState?) = read()
        override fun onSessionDestroyed() {
            pick(emptyList())
        }
    }

    fun start() {
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, listenerName)
            hasAccess = true
            pick(msm.getActiveSessions(listenerName))
        } catch (e: SecurityException) {
            hasAccess = false
            onChange()
        }
    }

    fun stop() {
        try {
            msm.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
        }
        controller?.unregisterCallback(callback)
        controller = null
    }

    private fun pick(list: List<MediaController>) {
        val best = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list.firstOrNull()
        if (best != null && controller != null && best.sessionToken == controller?.sessionToken) {
            read()
            return
        }
        controller?.unregisterCallback(callback)
        controller = best
        best?.registerCallback(callback)
        read()
    }

    private fun read() {
        val c = controller
        val m = c?.metadata
        title = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        artist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        cover = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: m?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        durationMs = m?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        playing = c?.playbackState?.state == PlaybackState.STATE_PLAYING
        onChange()
    }

    fun positionMs(): Long {
        val s = controller?.playbackState ?: return 0L
        if (s.state == PlaybackState.STATE_PLAYING) {
            val dt = SystemClock.elapsedRealtime() - s.lastPositionUpdateTime
            return s.position + (dt * s.playbackSpeed).toLong()
        }
        return s.position
    }
}

package com.mrsh1zuky.island

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(48), dp(24), dp(32))
        }
        col.addView(TextView(this).apply {
            text = "Island"
            textSize = 34f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        })
        col.addView(TextView(this).apply {
            text = "Остров у камеры: музыка, уведомления и не только"
            textSize = 14f
            setTextColor(0xFF999999.toInt())
            setPadding(0, dp(4), 0, dp(20))
        })

        status = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(16))
        }
        col.addView(status)

        col.addView(step("1. Разрешить поверх экрана") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        col.addView(step("2. Настройки приложения (разрешить ограниченные настройки)") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        })
        col.addView(step("3. Доступ к уведомлениям") {
            val i = if (Build.VERSION.SDK_INT >= 30) {
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS).putExtra(
                    Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
                    ComponentName(this, MediaListener::class.java).flattenToString()
                )
            } else {
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            }
            try {
                startActivity(i)
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        })
        col.addView(step("4. Спец. возможности → Island (остров поверх статус-бара)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(step("5. Батарея: поставить «Без ограничений»") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        col.addView(step("Запустить остров", primary = true) {
            Prefs.set(this, Prefs.ENABLED, true)
            val a11y = IslandAccessibilityService.instance
            if (a11y != null) {
                // служба спец. возможностей включена: остров рисуется выше статус-бара
                IslandHost.show(a11y, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
            } else {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                if (Settings.canDrawOverlays(this)) {
                    startForegroundService(Intent(this, IslandService::class.java))
                } else {
                    status.text = "Сначала включи шаг 1: поверх экрана (или шаг 4: спец. возможности)"
                }
            }
            refreshStatus()
        })
        col.addView(step("Остановить остров") {
            Prefs.set(this, Prefs.ENABLED, false)
            IslandHost.hide(null)
            stopService(Intent(this, IslandService::class.java))
            refreshStatus()
        })

        col.addView(TextView(this).apply {
            text = "Настройки"
            textSize = 20f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(22), 0, dp(6))
        })
        col.addView(toggle("Слова песни вместо названия", Prefs.LYRICS))
        col.addView(toggle("Слова проявляются волной", Prefs.WAVE))
        col.addView(toggle("Больше источников текстов (NetEase)", Prefs.EXTRA))
        col.addView(toggle("Размытая обложка на фоне", Prefs.BLUR))
        col.addView(toggle("Размытие неактивных строк в плеере", Prefs.LYR_BLUR))
        col.addView(toggle("Уведомления в острове", Prefs.NOTIFS))
        col.addView(TextView(this).apply {
            text = "Слова песен ищутся в интернете: название и исполнитель трека отправляются на lrclib.net, а если включён NetEase, то и туда. Больше ничего не отправляется."
            textSize = 12f
            setTextColor(0xFF777777.toInt())
            setPadding(0, dp(8), 0, 0)
        })

        col.addView(TextView(this).apply {
            text = "Размеры"
            textSize = 20f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(22), 0, dp(2))
        })
        val sliderRows = ArrayList<() -> Unit>()
        for (sl in Prefs.SLIDERS) col.addView(slider(sl, sliderRows))
        col.addView(step("Сбросить размеры") {
            Prefs.resetSliders(this)
            for (r in sliderRows) r()
            IslandHost.reload()
        }.apply {
            (layoutParams as LinearLayout.LayoutParams).topMargin = dp(12)
        })

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(col)
        }
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun refreshStatus() {
        val overlay = Settings.canDrawOverlays(this)
        val listeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        val listener = listeners.contains(packageName)
        val a11y = IslandAccessibilityService.connected
        status.text = "Поверх экрана: " + (if (overlay) "включено" else "нужно включить") +
            "\nДоступ к уведомлениям: " + (if (listener) "включено" else "нужно включить") +
            "\nСпец. возможности (остров над статус-баром): " + (if (a11y) "включено" else "не включено") +
            (if (!a11y) "\nБез них значки статус-бара будут рисоваться поверх острова." else "")
    }

    // Ползунок: значение сохраняется при отпускании, остров пересоздаётся сразу с новыми размерами
    private fun slider(s: Prefs.Slider, refreshers: MutableList<() -> Unit>): LinearLayout {
        val label = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
        }
        val bar = SeekBar(this).apply {
            max = s.max - s.min
            progressTintList = ColorStateList.valueOf(Color.WHITE)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
        }
        fun show(v: Int) {
            label.text = s.label + ": " + v + " " + s.unit
        }
        val read = {
            val v = Prefs.getInt(this, s.key)
            bar.progress = v - s.min
            show(v)
        }
        read()
        refreshers.add(read)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) show(p + s.min)
            }

            override fun onStartTrackingTouch(sb: SeekBar) {}

            override fun onStopTrackingTouch(sb: SeekBar) {
                Prefs.setInt(this@MainActivity, s.key, sb.progress + s.min)
                if (s.affectsIsland) IslandHost.reload()
            }
        })
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, dp(4))
            addView(label)
            addView(bar)
        }
    }

    private fun toggle(label: String, key: String): Switch {
        return Switch(this).apply {
            text = label
            textSize = 15f
            setTextColor(Color.WHITE)
            isChecked = Prefs.get(this@MainActivity, key)
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, v -> Prefs.set(this@MainActivity, key, v) }
        }
    }

    private fun step(label: String, primary: Boolean = false, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(if (primary) Color.BLACK else Color.WHITE)
            background = GradientDrawable().apply {
                setColor(if (primary) Color.WHITE else 0x26FFFFFF)
                cornerRadius = dp(28).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56)
            ).apply { setMargins(0, 0, 0, dp(10)) }
            gravity = Gravity.CENTER
            setOnClickListener { action() }
        }
    }
}

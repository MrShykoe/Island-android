package com.mrsh1zuky.island

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager

// Единое место, где остров добавляется в окно и убирается. Одновременно существует только один остров.
// Окно типа ACCESSIBILITY_OVERLAY лежит выше статус-бара, поэтому часы и значки его не перекрывают;
// обычное окно «поверх экрана» (APPLICATION_OVERLAY) статус-бар перекрывает: оно запасной вариант.
object IslandHost {
    private var view: IslandView? = null
    private var owner: Context? = null
    private var type = 0

    val running get() = view != null

    fun show(owner: Context, type: Int) {
        hide(null)
        val wm = owner.getSystemService(WindowManager::class.java) ?: return
        val v = IslandView(owner)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = v.topY // чтобы остров сидел точно вокруг камеры
        lp.title = "Island"
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        try {
            wm.addView(v, lp)
        } catch (e: Exception) {
            v.release()
            return
        }
        view = v
        this.owner = owner
        this.type = type
    }

    // who = null: убрать в любом случае; иначе только если остров принадлежит этому сервису
    fun hide(who: Context?) {
        if (who != null && who !== owner) return
        val v = view ?: return
        v.release()
        try {
            owner?.getSystemService(WindowManager::class.java)?.removeView(v)
        } catch (e: Exception) {
        }
        view = null
        owner = null
    }

    // Пересоздать остров с новыми настройками (размеры, отступы)
    fun reload() {
        val o = owner
        if (o != null && view != null) show(o, type)
    }
}

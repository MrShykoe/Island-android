package com.mrsh1zuky.island

import android.app.Notification
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

// Доступ к уведомлениям нужен и для музыки (Android так требует), и чтобы показывать их в острове.
class MediaListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (sbn.packageName == packageName) return
            val n = sbn.notification
            if (sbn.isOngoing || (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
            if (n.category == Notification.CATEGORY_TRANSPORT || n.category == Notification.CATEGORY_PROGRESS) return
            val e = n.extras
            val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = (e.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: e.getCharSequence(Notification.EXTRA_TEXT))
                ?.toString() ?: ""
            if (title.isEmpty() && text.isEmpty()) return
            val pm = packageManager
            val label = try {
                pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
            } catch (ex: Exception) {
                sbn.packageName
            }
            val icon = try {
                pm.getApplicationIcon(sbn.packageName)
            } catch (ex: Exception) {
                null
            }
            Notifs.post(Notifs.Item(label, title, text, icon))
        } catch (ex: Exception) {
        }
    }
}

object Notifs {
    class Item(val app: String, val title: String, val text: String, val icon: Drawable?)

    var listener: ((Item) -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())

    fun post(i: Item) {
        main.post { listener?.invoke(i) }
    }
}

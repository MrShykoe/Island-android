package com.mrsh1zuky.island

import android.service.notification.NotificationListenerService

// Сам по себе пустой: наличие этого сервиса и выданный доступ к уведомлениям
// нужны, чтобы Android разрешил читать музыку из других приложений.
// Позже здесь же появятся уведомления в острове.
class MediaListener : NotificationListenerService()

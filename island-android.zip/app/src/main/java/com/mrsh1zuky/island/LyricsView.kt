package com.mrsh1zuky.island

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.os.SystemClock
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ============================================================
//  Слова песни в стиле Яндекс Музыки:
//  - активная строка яркая, остальные тусклые и слегка уменьшены;
//  - внутри активной строки слова заливаются белым вслед за голосом (в том числе на несколько строк);
//  - строки плавно «подъезжают» каскадом, соседние чуть размыты;
//  - тап по строке перематывает трек, ручной скролл не мешает: через пару секунд список возвращается.
// ============================================================
class LyricsView(ctx: Context) : ScrollView(ctx) {

    var onLineClick: ((Double) -> Unit)? = null

    var textSp = 28f
        set(v) {
            field = v
            for (l in lines) l.setTextSp(v)
        }
    var fillWords = true
        set(v) {
            field = v
            for (l in lines) l.fillOn = v
        }
    var blurOn = true

    private val density = resources.displayMetrics.density
    private val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val topSpace = View(ctx)
    private val botSpace = View(ctx)
    private val lines = ArrayList<LyricLine>()
    private var data: List<Media.Line>? = null
    private var cur = -2
    private var focusAnim: ValueAnimator? = null
    private var returnAnim: ObjectAnimator? = null
    private var lastTouch = 0L
    private var browsing = false
    private var pendingSnap = false
    private val spring = PathInterpolator(0.22f, 1f, 0.36f, 1f)

    init {
        isVerticalScrollBarEnabled = false
        overScrollMode = OVER_SCROLL_NEVER
        isVerticalFadingEdgeEnabled = true
        setFadingEdgeLength((64 * density).toInt())
        addView(box, FrameLayout.LayoutParams(-1, -2))
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        topSpace.layoutParams = LinearLayout.LayoutParams(-1, (h * 0.34f).toInt())
        botSpace.layoutParams = LinearLayout.LayoutParams(-1, (h * 0.66f).toInt())
        pendingSnap = true
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        if (pendingSnap && lines.isNotEmpty() && lines[0].height > 0) {
            pendingSnap = false
            if (!browsing) scrollTo(0, targetFor(cur))
        }
    }

    fun setLines(newLines: List<Media.Line>?) {
        if (newLines === data) return
        data = newLines
        cur = -2
        focusAnim?.cancel()
        returnAnim?.cancel()
        lines.clear()
        box.removeAllViews()
        browsing = false
        scrollTo(0, 0)
        if (newLines == null) return
        box.addView(topSpace)
        for (l in newLines) {
            val v = LyricLine(context, l, textSp)
            v.fillOn = fillWords
            v.setOnClickListener {
                // перемотка к строке: сразу разрешаем списку ехать за голосом
                lastTouch = 0L
                browsing = false
                onLineClick?.invoke(l.t)
            }
            lines.add(v)
            box.addView(v, LinearLayout.LayoutParams(-1, -2))
        }
        box.addView(botSpace)
        pendingSnap = true
    }

    // Вызывать каждый кадр с текущим временем трека в секундах
    fun update(t: Double) {
        val d = data ?: return
        var idx = -1
        for (i in d.indices) {
            if (d[i].t <= t) idx = i else break
        }
        if (idx != cur) onActive(idx)
        if (idx in lines.indices) lines[idx].setTime(t)

        if (returnAnim?.isRunning != true && cur >= 0 && !touching() && lastTouch != 0L) {
            // пользователь дал списку покой: плавно возвращаемся к текущей строке
            if (browsing) {
                browsing = false
                animateFocus(cur)
            }
            val target = targetFor(cur)
            if (abs(scrollY - target) > 6 * density) {
                returnAnim = ObjectAnimator.ofInt(this, "scrollY", scrollY, target).apply {
                    duration = 550
                    interpolator = DecelerateInterpolator(2f)
                    start()
                }
            }
            lastTouch = 0L
        }
    }

    private fun touching() = SystemClock.elapsedRealtime() - lastTouch < 3000

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                returnAnim?.cancel()
                if (!browsing) {
                    browsing = true
                    animateFocus(cur) // пока листаем, размытие убираем
                }
                lastTouch = SystemClock.elapsedRealtime()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> lastTouch = SystemClock.elapsedRealtime()
        }
        return super.onTouchEvent(ev)
    }

    private fun targetFor(idx: Int): Int {
        if (idx < 0 || idx >= lines.size) return 0
        val v = lines[idx]
        return max(0, (v.top + v.height / 2f - height * 0.34f - 0f).roundToInt())
    }

    private fun onActive(idx: Int) {
        val old = cur
        cur = idx
        if (old in lines.indices) lines[old].finish()
        animateFocus(idx)
        if (browsing || touching() || lines.isEmpty() || lines[0].height == 0) return
        val target = targetFor(idx)
        val delta = target - scrollY
        if (delta == 0) return
        returnAnim?.cancel()
        scrollTo(0, target)
        cascade(delta, idx)
    }

    // Строки не прыгают, а подъезжают с небольшой задержкой, начиная с активной
    private fun cascade(delta: Int, idx: Int) {
        val sy = scrollY
        val far = abs(delta) > height * 1.6f
        for ((i, v) in lines.withIndex()) {
            v.animate().cancel()
            val onScreen = v.bottom - sy > -200 && v.top - sy < height + 200
            if (far || !onScreen) {
                v.translationY = 0f
                continue
            }
            v.translationY = delta.toFloat()
            val order = max(0, i - max(idx, 0))
            v.animate().translationY(0f)
                .setStartDelay(min(order * 45L, 360L))
                .setDuration(560)
                .setInterpolator(spring)
                .start()
        }
    }

    // Яркость, размер и размытие каждой строки плавно переходят к новым значениям
    private fun animateFocus(active: Int) {
        focusAnim?.cancel()
        val n = lines.size
        if (n == 0) return
        val fromF = FloatArray(n) { lines[it].focus }
        val fromB = FloatArray(n) { lines[it].blurR }
        val toF = FloatArray(n) { if (it == active) 1f else 0f }
        val unit = 1.5f * density
        val toB = FloatArray(n) {
            if (!blurOn || browsing || it == active) 0f else min(abs(it - active), 4) * unit
        }
        val changed = (0 until n).filter { fromF[it] != toF[it] || fromB[it] != toB[it] }
        if (changed.isEmpty()) return
        focusAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 480
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { va ->
                val f = va.animatedValue as Float
                for (i in changed) {
                    val l = lines[i]
                    l.setFocus(fromF[i] + (toF[i] - fromF[i]) * f)
                    l.setBlur(fromB[i] + (toB[i] - fromB[i]) * f)
                }
            }
            start()
        }
    }
}

// Одна строка текста: сама рисует слова с заливкой по символам
class LyricLine(ctx: Context, val line: Media.Line, sp: Float) : View(ctx) {

    var focus = 0f
        private set
    var blurR = 0f
        private set
    var fillOn = true

    private val dimAlpha = 0.36f
    private val padH = (8 * resources.displayMetrics.density).toInt()
    private val padV = (10 * resources.displayMetrics.density).toInt()
    private val text: String = if (line.s.isBlank()) "• • •" else line.s
    private val words: List<Media.Word> = if (line.s.isBlank()) emptyList() else line.timing
    private val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, 800, false)
        color = Color.WHITE
    }
    private var layout: StaticLayout? = null
    private var layoutW = -1
    private var cp = -1f // сколько символов уже «спето»; меньше нуля = без заливки
    private var lastBlurStep = -1

    init {
        setTextSp(sp)
        scaleX = 0.92f
        scaleY = 0.92f
    }

    fun setTextSp(sp: Float) {
        paint.textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, resources.displayMetrics)
        layout = null
        requestLayout()
        invalidate()
    }

    fun setFocus(f: Float) {
        focus = f
        val s = 0.92f + 0.08f * f
        scaleX = s
        scaleY = s
        invalidate()
    }

    fun setBlur(r: Float) {
        blurR = r
        if (Build.VERSION.SDK_INT < 31) return
        val step = (r * 2f).roundToInt() // обновляем эффект только при заметном изменении
        if (step == lastBlurStep) return
        lastBlurStep = step
        setRenderEffect(
            if (step == 0) null else RenderEffect.createBlurEffect(step / 2f, step / 2f, Shader.TileMode.DECAL)
        )
    }

    fun setTime(t: Double) {
        if (words.isEmpty()) return
        val n = Timing.charPos(words, t, text.length)
        if (n != cp) {
            cp = n
            invalidate()
        }
    }

    fun finish() {
        if (words.isEmpty()) return
        cp = text.length.toFloat()
        invalidate()
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        val tw = max(1, w - 2 * padH)
        if (layout == null || layoutW != tw) {
            layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, tw)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setLineSpacing(0f, 1.05f)
                .setBreakStrategy(Layout.BREAK_STRATEGY_BALANCED)
                .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE)
                .build()
            layoutW = tw
        }
        setMeasuredDimension(w, (layout?.height ?: 0) + 2 * padV)
    }

    override fun onDraw(c: Canvas) {
        val lo = layout ?: return
        val bright = Color.argb(((dimAlpha + (1f - dimAlpha) * focus) * 255).roundToInt(), 255, 255, 255)
        val dim = Color.argb((dimAlpha * 255).roundToInt(), 255, 255, 255)
        val soft = paint.textSize * 0.7f
        c.save()
        c.translate(padH.toFloat(), padV.toFloat())
        val filled = fillOn && cp >= 0f && focus > 0.001f
        for (i in 0 until lo.lineCount) {
            val ls = lo.getLineStart(i)
            var le = lo.getLineEnd(i)
            while (le > ls && text[le - 1].isWhitespace()) le--
            if (le <= ls) continue
            val x0 = lo.getLineLeft(i)
            val x1 = lo.getLineRight(i)
            val base = lo.getLineBaseline(i).toFloat()
            if (filled && x1 > x0) {
                val fx = when {
                    cp <= ls -> x0 - soft
                    cp >= le -> x1 + soft
                    else -> {
                        val k = cp.toInt().coerceIn(ls, le - 1)
                        val xa = lo.getPrimaryHorizontal(k)
                        val xb = if (k + 1 < le) lo.getPrimaryHorizontal(k + 1) else x1
                        xa + (cp - k) * (xb - xa)
                    }
                }
                val span = x1 - x0
                val a = ((fx - soft / 2f - x0) / span).coerceIn(0f, 1f)
                val b = ((fx + soft / 2f - x0) / span).coerceIn(a, 1f)
                paint.shader = LinearGradient(
                    x0, 0f, x1, 0f,
                    intArrayOf(bright, bright, dim, dim),
                    floatArrayOf(0f, a, b, 1f), Shader.TileMode.CLAMP
                )
                paint.color = Color.WHITE
            } else {
                paint.shader = null
                paint.color = bright
            }
            c.drawText(text, ls, le, x0, base, paint)
        }
        paint.shader = null
        c.restore()
    }
}
